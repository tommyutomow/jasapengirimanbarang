package paketReguler;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.swing.JOptionPane;

public class databasepacketReguler {
	private Connection conn = null;
	static final String driver = "com.mysql.jdbc.Driver";
	static final String db_url = "jdbc:mysql://localhost:3306/jasakirimbarang";
	static final String username = "root";
	static final String password= "";


public databasepacketReguler() throws ClassNotFoundException{
	Class.forName(driver);
}

public void opendb() throws SQLException{
	conn = DriverManager.getConnection(db_url,username,password);
}

public void closedb() throws SQLException{
	if(conn!=null) conn.close();
}

public ResultSet getpaketreguler() throws SQLException{
	opendb();
	Statement stmt = conn.createStatement();
	ResultSet rs = stmt.executeQuery("SELECT * FROM paketreguler ORDER BY ID_PaketReguler ASC");
	return rs;
}

public ArrayList<classpaketReguler> getkotatujuan() throws SQLException{
	opendb();
	Statement stmt = conn.createStatement();
	ResultSet rs  = stmt.executeQuery("SELECT * FROM kotatujuan ORDER BY Nama_KotaTujuan ASC");
	
	ArrayList<classpaketReguler> arr = new ArrayList<classpaketReguler>();
	while (rs.next()){
		classpaketReguler kotatujuan = new classpaketReguler();
		kotatujuan.setKotatujuan(rs.getString(2));
		arr.add(kotatujuan);
	}
	closedb();
	return arr;
}

public ArrayList<classpaketReguler> getkotadari() throws SQLException{
	opendb();
	Statement stmt = conn.createStatement();
	ResultSet rs  = stmt.executeQuery("SELECT * FROM kotadari ORDER BY Nama_KotaDari ASC");
	
	ArrayList<classpaketReguler> arr = new ArrayList<classpaketReguler>();
	while (rs.next()){
		classpaketReguler kotadari = new classpaketReguler();
		kotadari.setKotadari(rs.getString(2));
		arr.add(kotadari);
	}
	closedb();
	return arr;
}

public void addPaketreguler(String ID_PaketReguler, String Kota_Dari,String Kota_Tujuan,int Hargakg) throws SQLException{
	opendb();
	String query = "INSERT INTO paketreguler (ID_PaketReguler, Kota_Dari, Kota_Tujuan, Hargakg) VALUES(?,?,?,?)";
	PreparedStatement ps = conn.prepareStatement(query);
	
	// Index dimulai dari 1 bukan 0. Index merepresentasikan urutan ?
	ps.setString(1, ID_PaketReguler);
	ps.setString(2, Kota_Dari);
	ps.setString(3,Kota_Tujuan );
	ps.setInt(4, Hargakg);


	
	conn.setAutoCommit(false);
	int result = ps.executeUpdate();
	if(result == 1){
		JOptionPane.showMessageDialog(null, "Data telah disimpan");
		//System.out.println("Insert Success!");
		conn.commit();
	}else{
		JOptionPane.showMessageDialog(null, "Data gagal disimpan");
	}
	closedb();
}

public void updatePaketReguler(String ID_PaketReguler, String Kota_Dari,String Kota_Tujuan,int Hargakg) throws SQLException{
opendb();
String query = "UPDATE paketreguler SET Kota_Dari=?, Kota_Tujuan=?, Hargakg=?  WHERE ID_PaketReguler = ? ";
PreparedStatement ps = conn.prepareStatement(query);
	ps.setString(1, Kota_Dari);
	ps.setString(2,Kota_Tujuan );
	ps.setInt(3, Hargakg);

	ps.setString(4, ID_PaketReguler);
	
	conn.setAutoCommit(false);
	int result = ps.executeUpdate();
	if(result == 1){
		JOptionPane.showMessageDialog(null, "Data telah diupdate");
		conn.commit();
		}else{
			JOptionPane.showMessageDialog(null, "Data gagal disimpan");
		}
	closedb();
	
}

public void deletePaketReguler(String ID_PaketReguler) throws SQLException{
	opendb();
	String query = "Delete FROM paketreguler WHERE ID_PaketReguler = ? ";
	PreparedStatement ps = conn.prepareStatement(query);
	ps.setString(1, ID_PaketReguler);
	conn.setAutoCommit(false);
	
	int result = ps.executeUpdate();
	if(result == 1){
		JOptionPane.showMessageDialog(null, "Data telah didelete");
		conn.commit();
		}else{
			JOptionPane.showMessageDialog(null, "Data gagal disimpan");
		}
	closedb();
}

}

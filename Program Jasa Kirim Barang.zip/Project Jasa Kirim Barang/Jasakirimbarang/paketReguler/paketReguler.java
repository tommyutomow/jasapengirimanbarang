package paketReguler;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;



import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Toolkit;

import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JTable;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;

public class paketReguler extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTable table;
	private DefaultTableModel model;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					paketReguler frame = new paketReguler();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * @throws ClassNotFoundException 
	 * @throws SQLException 
	 */
	public paketReguler() throws ClassNotFoundException, SQLException {
		super("Master Paket Regular");
		databasepacketReguler db =new databasepacketReguler();
		db.opendb();
		
		ArrayList<classpaketReguler> arrkotatujuan = new ArrayList<classpaketReguler>();
		arrkotatujuan = db.getkotatujuan();
		ArrayList<classpaketReguler> arrkotadari = new ArrayList<classpaketReguler>();
		arrkotadari = db.getkotadari();
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 650, 500);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		Dimension frameSize = getSize();
		setLocation(
		(screenSize.width - frameSize.width) / 2,
		(screenSize.height - frameSize.height) / 2);
		
		JLabel lblIdPaketReguler = new JLabel("ID Paket Reguler :");
		lblIdPaketReguler.setFont(new Font("Arial Black", Font.PLAIN, 14));
		lblIdPaketReguler.setBounds(162, 93, 149, 32);
		contentPane.add(lblIdPaketReguler);
		
		textField = new JTextField();
		textField.setBounds(321, 99, 160, 25);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblKotaDari = new JLabel("Kota Dari :");
		lblKotaDari.setFont(new Font("Arial Black", Font.PLAIN, 14));
		lblKotaDari.setBounds(162, 126, 149, 25);
		contentPane.add(lblKotaDari);
		
		JLabel lblKotaTujuan = new JLabel("Kota Tujuan :");
		lblKotaTujuan.setFont(new Font("Arial Black", Font.PLAIN, 14));
		lblKotaTujuan.setBounds(162, 155, 149, 32);
		contentPane.add(lblKotaTujuan);
		
		
		
		JComboBox comboBox = new JComboBox();
		comboBox.setBounds(321, 128, 160, 25);
		contentPane.add(comboBox);
		
		for(int i=0;i<arrkotadari.size();i++){
			comboBox.addItem(arrkotadari.get(i).getKotadari());
		 }
		
		JComboBox comboBox_1 = new JComboBox();
		comboBox_1.setBounds(321, 161, 160, 25);
		contentPane.add(comboBox_1);
		
		for(int i=0;i<arrkotatujuan.size();i++){
			comboBox_1.addItem(arrkotatujuan.get(i).getKotatujuan());
		 }
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(321, 195, 160, 25);
		contentPane.add(textField_1);
		
		JLabel lblHarga = new JLabel("Harga :");
		lblHarga.setFont(new Font("Arial Black", Font.PLAIN, 14));
		lblHarga.setBounds(162, 195, 149, 25);
		contentPane.add(lblHarga);
		
		String[] judul ={"ID Packet Reguler","Kota Dari","Kota Tujuan","Harga"};
		table = new JTable(){
			public boolean isCellEditable(int rowIndex, int colIndex) 
			{
				return false;
			}
		};
		
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) 
			{
				int pilih = table.getSelectedRow();
				if(pilih == -1)
				{
					return;
				}
				comboBox_1.setEditable(true);
				comboBox.setEditable(true);
				String idpaketreguler = (String) model.getValueAt(pilih, 0);
				textField.setText(idpaketreguler);
				String kotadari = (String) model.getValueAt(pilih, 1);
				comboBox.setSelectedItem(kotadari);
				String kotatujuan = (String) model.getValueAt(pilih, 2);
				comboBox_1.setSelectedItem(kotatujuan);
				String hargakg = (String) model.getValueAt(pilih, 3);
				textField_1.setText(hargakg);
			}
		});
		
		model = new DefaultTableModel(null,judul);
		
		table.setModel(model);
		table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		table.getColumnModel().getColumn(0).setPreferredWidth(112);
		table.getColumnModel().getColumn(1).setPreferredWidth(132);
		table.getColumnModel().getColumn(2).setPreferredWidth(132);
		table.getColumnModel().getColumn(3).setPreferredWidth(122);
		
		tampil();
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(51, 244, 520, 158);
		scrollPane.setVisible(true);
		contentPane.add(scrollPane);
		scrollPane.setViewportView(table);
		
		JButton btnInsert = new JButton("Insert");
		btnInsert.setFont(new Font("Arial Black", Font.PLAIN, 14));
		btnInsert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				 String id_paket  = textField.getText();
				 String kotadari  = comboBox.getSelectedItem().toString();;
				 String kotatujuan  = comboBox_1.getSelectedItem().toString();
				 int hargakg = (int) Double.parseDouble(textField_1.getText());
				try {
					db.addPaketreguler(id_paket,kotadari,kotatujuan,hargakg);
					try {
						model.getDataVector().removeAllElements(); //remove table 
						tampil();
						textField.setText("");
						textField_1.setText("");
					} catch (ClassNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnInsert.setBounds(51, 413, 104, 32);
		contentPane.add(btnInsert);
		
		JButton btnUpdate = new JButton("Update");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				 String id_paket  = textField.getText();
				 String kotadari  = comboBox.getSelectedItem().toString();;
				 String kotatujuan  = comboBox_1.getSelectedItem().toString();
				 int hargakg = (int) Double.parseDouble(textField_1.getText());
						 try{
			 db.updatePaketReguler(id_paket, kotadari, kotatujuan, hargakg);
					 try{
						 model.getDataVector().removeAllElements();
							tampil();
							textField.setText("");
							textField_1.setText("");
					 }catch (ClassNotFoundException e1){
							e1.printStackTrace();
					 }
						}catch (SQLException e1) {
							e1.printStackTrace();
						}
			}
		});
		
		btnUpdate.setFont(new Font("Arial Black", Font.PLAIN, 14));
		btnUpdate.setBounds(269, 413, 104, 32);
		contentPane.add(btnUpdate);
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String id_paket = textField.getText();
				
				try{
					db.deletePaketReguler(id_paket);
				try{
					model.getDataVector().removeAllElements();
					tampil();
					textField.setText("");
					textField_1.setText("");
				}catch (ClassNotFoundException e1){
					e1.printStackTrace();
				}
				}catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		});
		btnDelete.setFont(new Font("Arial Black", Font.PLAIN, 14));
		btnDelete.setBounds(467, 413, 104, 32);
		contentPane.add(btnDelete);
		
		JLabel lblNewLabel = new JLabel("Flash");
		lblNewLabel.setForeground(new Color(255, 102, 0));
		lblNewLabel.setFont(new Font("Clarendon Blk BT", Font.PLAIN, 60));
		lblNewLabel.setBounds(150, 11, 188, 59);
		contentPane.add(lblNewLabel);
		
		JLabel lblExpress = new JLabel("Express");
		lblExpress.setFont(new Font("Clarendon Blk BT", Font.PLAIN, 30));
		lblExpress.setForeground(new Color(51, 0, 204));
		lblExpress.setBounds(335, 33, 136, 36);
		contentPane.add(lblExpress);
	}
	
	public void tampil() throws ClassNotFoundException, SQLException{
		databasepacketReguler db = new databasepacketReguler();
		ResultSet rs = db.getpaketreguler();
		while(rs.next()){
			String idpaketreguler = rs.getString(1);
			String kotadari = rs.getString(2);
			String kotatujuan = rs.getString(3);
			String hargakg = String.valueOf(rs.getInt(4));
			String[] row ={idpaketreguler,kotadari,kotatujuan,hargakg};
			model.addRow(row);
		}
		rs.close();
	}
	
}

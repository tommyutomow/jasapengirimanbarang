package paketReguler;

public class classpaketReguler {
	private String idpaketreguler;
	private String kotadari;
	private String kotatujuan;
	private String harga;
	
	
	public String getIdpaketreguler() {
		return idpaketreguler;
	}
	public void setIdpaketreguler(String idpaketreguler) {
		this.idpaketreguler = idpaketreguler;
	}
	public String getKotadari() {
		return kotadari;
	}
	public void setKotadari(String kotadari) {
		this.kotadari = kotadari;
	}
	public String getKotatujuan() {
		return kotatujuan;
	}
	public void setKotatujuan(String kotatujuan) {
		this.kotatujuan = kotatujuan;
	}
	public String getHarga() {
		return harga;
	}
	public void setHarga(String harga) {
		this.harga = harga;
	}
	
	
	

	
}

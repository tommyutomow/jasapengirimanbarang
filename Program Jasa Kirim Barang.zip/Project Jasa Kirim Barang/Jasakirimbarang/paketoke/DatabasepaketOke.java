package paketoke;
import java.sql.*;
import java.util.ArrayList;

import javax.swing.JOptionPane;
public class DatabasepaketOke {
	private Connection conn = null;
	static final String driver = "com.mysql.jdbc.Driver";
	static final String db_url = "jdbc:mysql://localhost:3306/jasakirimbarang";
	static final String username = "root";
	static final String password= "";
	
	public DatabasepaketOke() throws ClassNotFoundException{
		Class.forName(driver);
	}
	
	public void opendb() throws SQLException{
		conn = DriverManager.getConnection(db_url,username,password);
	}
	
	public void closedb() throws SQLException{
		if(conn!=null) conn.close();
	}
	
	
	public ResultSet getpaketoke() throws SQLException{
		opendb();
		Statement stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery("SELECT * FROM paketoke ORDER BY ID_PaketOke ASC ");
		return rs;
	}
	
	
	public ArrayList<classpaketOke> getkotatujuan() throws SQLException{
		opendb();
		Statement stmt = conn.createStatement();
		ResultSet rs  = stmt.executeQuery("SELECT * FROM kotatujuan ORDER BY Nama_KotaTujuan ASC");
		
		ArrayList<classpaketOke> arr = new ArrayList<classpaketOke>();
		while (rs.next()){
			classpaketOke kotatujuan = new classpaketOke();
			kotatujuan.setKotatujuan(rs.getString(2));
			arr.add(kotatujuan);
		}
		closedb();
		return arr;
	}
	public ArrayList<classpaketOke> getkotadari() throws SQLException{
		opendb();
		Statement stmt = conn.createStatement();
		ResultSet rs  = stmt.executeQuery("SELECT * FROM kotadari ORDER BY Nama_KotaDari ASC");
		
		ArrayList<classpaketOke> arr = new ArrayList<classpaketOke>();
		while (rs.next()){
			classpaketOke kotadari = new classpaketOke();
			kotadari.setKotadari(rs.getString(2));
			arr.add(kotadari);
		}
		closedb();
		return arr;
	}
	public void addPaketoke(String ID_PaketOke, String Kota_Dari,String Kota_Tujuan,int Hargakg) throws SQLException{
		opendb();
		String query = "INSERT INTO paketoke(ID_PaketOke, Kota_Dari, Kota_Tujuan, Hargakg) VALUES(?,?,?,?)";
		PreparedStatement ps = conn.prepareStatement(query);
		
		// Index dimulai dari 1 bukan 0. Index merepresentasikan urutan ?
		ps.setString(1, ID_PaketOke);
		ps.setString(2, Kota_Dari);
		ps.setString(3,Kota_Tujuan );
		ps.setInt(4, Hargakg);

		
		conn.setAutoCommit(false);
		int result = ps.executeUpdate();
		if(result == 1){
			JOptionPane.showMessageDialog(null,"Insert Success!");
			conn.commit();
		}else{
			JOptionPane.showMessageDialog(null,"Insert Gagal!");
		}
		closedb();
	}
	public void updatePaketoke(String kotadari, String kotatujuan,int Hargakg,String ID_PaketOke) throws SQLException{
		opendb();
		String query = "UPDATE paketoke SET Kota_Dari=?, Kota_Tujuan=?, Hargakg= ? WHERE ID_PaketOke = ?";
		PreparedStatement ps = conn.prepareStatement(query);
		
		// Index dimulai dari 1 bukan 0. Index merepresentasikan urutan ?
		ps.setString(4, ID_PaketOke);
		ps.setString(1, kotadari);
		ps.setString(2, kotatujuan);
		ps.setInt(3, Hargakg);
		//ps.setInt(5, Hargavolume);

		
		conn.setAutoCommit(false);
		int result = ps.executeUpdate();
		if(result == 1){
			JOptionPane.showMessageDialog(null,"Update Success!");
			conn.commit();
		}else{
			JOptionPane.showMessageDialog(null,"Update Gagal!");
		}
		closedb();
	}
	public void deletePaketoke(String ID_PaketOke) throws SQLException{
		opendb();
		String query = "DELETE from paketoke WHERE ID_PaketOke = ?";
		PreparedStatement ps = conn.prepareStatement(query);
		
		// Index dimulai dari 1 bukan 0. Index merepresentasikan urutan ?
		ps.setString(1, ID_PaketOke);

		
		conn.setAutoCommit(false);
		int result = ps.executeUpdate();
		if(result == 1){
			JOptionPane.showMessageDialog(null,"Delete Success!");
			conn.commit();
		}else{
			JOptionPane.showMessageDialog(null,"Delete Gagal!");
		}
		closedb();
	}
	
}

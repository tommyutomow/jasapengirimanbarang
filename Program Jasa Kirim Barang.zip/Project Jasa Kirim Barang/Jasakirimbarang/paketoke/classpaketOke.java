package paketoke;

public class classpaketOke {
	private String idtarif;
	private String kotadari;
	private String kotatujuan;
	private int hargakg;
	private int hargavolume;
	
	public String getIdtarif() {
		return idtarif;
	}
	public void setIdtarif(String idtarif) {
		this.idtarif = idtarif;
	}
	public String getKotadari() {
		return kotadari;
	}
	public void setKotadari(String kotadari) {
		this.kotadari = kotadari;
	}
	public String getKotatujuan() {
		return kotatujuan;
	}
	public void setKotatujuan(String kotatujuan) {
		this.kotatujuan = kotatujuan;
	}
	public int getHargakg() {
		return hargakg;
	}
	public void setHargakg(int hargakg) {
		this.hargakg = hargakg;
	}
	public int getHargavolume() {
		return hargavolume;
	}
	public void setHargavolume(int hargavolume) {
		this.hargavolume = hargavolume;
	}

}

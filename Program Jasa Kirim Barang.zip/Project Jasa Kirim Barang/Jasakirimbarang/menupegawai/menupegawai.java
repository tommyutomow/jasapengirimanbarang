package menupegawai;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;
import java.awt.event.*;
import java.sql.SQLException;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JToolBar;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.ButtonGroup;
import javax.swing.event.MenuKeyListener;
import javax.swing.event.MenuKeyEvent;
import javax.swing.event.MenuListener;

import Customer.customerFrame;
import KotaTujuan.KotaTujuan;
import paketReguler.paketReguler;
import paketoke.paketokeinterface;
import paketyes.paketyesinterface;
import transaksi.transaksi;
import updateStatus.updateStatus;
import KotaDari.KotaDari;

import javax.swing.event.MenuEvent;

public class menupegawai extends JFrame {

	private JPanel contentPane;
	private final ButtonGroup buttonGroup = new ButtonGroup();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					menupegawai frame = new menupegawai();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public menupegawai() {
		super("Main Menu");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		Dimension frameSize = getSize();
		setLocation(
		(screenSize.width - frameSize.width) / 2,
		(screenSize.height - frameSize.height) / 2);
		
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnTransaksi = new JMenu("Transaksi");
		menuBar.add(mnTransaksi);
		
		JMenuItem mntmTransaksi = new JMenuItem("Transaksi");
		mntmTransaksi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					new transaksi().setVisible(true);
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		mnTransaksi.add(mntmTransaksi);
		
		JMenu mnUpdateStatus = new JMenu("Update Status");
		menuBar.add(mnUpdateStatus);
		
		JMenuItem mntmUpdateStatus = new JMenuItem("Update Status");
		mntmUpdateStatus.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					new updateStatus().setVisible(true);
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		mnUpdateStatus.add(mntmUpdateStatus);
		
		JMenu mnExit = new JMenu("Exit");
		mnExit.addMenuListener(new MenuListener() {
			public void menuCanceled(MenuEvent arg0) {
			}
			public void menuDeselected(MenuEvent arg0) {
			}
			public void menuSelected(MenuEvent arg0) {
				setVisible(false);
			}
		});
		menuBar.add(mnExit);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
	}

}

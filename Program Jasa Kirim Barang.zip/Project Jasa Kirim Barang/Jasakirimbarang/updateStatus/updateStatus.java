package updateStatus;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.DateFormatter;

import paketReguler.classpaketReguler;
import paketReguler.databasepacketReguler;

import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;

public class updateStatus extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_3;
	private JTable table;
	private DefaultTableModel model;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					updateStatus frame = new updateStatus();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 */
	public updateStatus() throws ClassNotFoundException, SQLException {
		super("Update Status");
		databaseupdateStatus db =new databaseupdateStatus();
		db.opendb();

		ArrayList<classupdateStatus> arrStatus = new ArrayList<classupdateStatus>();
		arrStatus = db.getstatus();
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 700, 500);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		Dimension frameSize = getSize();
		setLocation(
		(screenSize.width - frameSize.width) / 2,
		(screenSize.height - frameSize.height) / 2);
		
		JLabel label = new JLabel("Flash");
		label.setForeground(new Color(255, 102, 0));
		label.setFont(new Font("Clarendon Blk BT", Font.PLAIN, 60));
		label.setBounds(182, 0, 188, 59);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("Express");
		label_1.setForeground(new Color(51, 0, 204));
		label_1.setFont(new Font("Clarendon Blk BT", Font.PLAIN, 30));
		label_1.setBounds(367, 22, 136, 36);
		contentPane.add(label_1);
		
		JLabel lblIdTransaksi = new JLabel("ID Transaksi :");
		lblIdTransaksi.setFont(new Font("Arial Black", Font.PLAIN, 14));
		lblIdTransaksi.setBounds(166, 101, 149, 32);
		contentPane.add(lblIdTransaksi);
		
		textField = new JTextField();
		textField.setColumns(10);
		textField.setBounds(352, 107, 160, 25);
		contentPane.add(textField);
		
		JLabel lblStatusBarang = new JLabel("Status Barang :");
		lblStatusBarang.setFont(new Font("Arial Black", Font.PLAIN, 14));
		lblStatusBarang.setBounds(166, 144, 149, 32);
		contentPane.add(lblStatusBarang);
		
		JLabel lblTanggalTransaksi = new JLabel("Tanggal Transaksi :");
		lblTanggalTransaksi.setFont(new Font("Arial Black", Font.PLAIN, 14));
		lblTanggalTransaksi.setBounds(166, 189, 166, 32);
		contentPane.add(lblTanggalTransaksi);
		
		JLabel lblJamTransaksi = new JLabel("Jam Transaksi :");
		lblJamTransaksi.setFont(new Font("Arial Black", Font.PLAIN, 14));
		lblJamTransaksi.setBounds(166, 232, 166, 32);
		contentPane.add(lblJamTransaksi);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(352, 238, 160, 25);
		contentPane.add(textField_3);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setBounds(352, 143, 160, 25);
		contentPane.add(comboBox);
		comboBox.addItem("Manifest");
		comboBox.addItem("On Process");
		comboBox.addItem("On Transit");
		comboBox.addItem("Received on Destination");
		comboBox.addItem("Delivered");
		comboBox.addItem("Redelivery");
		
		JButton btnUpdate = new JButton("Update");
		btnUpdate.setFont(new Font("Arial Black", Font.PLAIN, 14));
		btnUpdate.setBounds(422, 274, 89, 36);
		contentPane.add(btnUpdate);
		
		
		DateFormat tglformat = new SimpleDateFormat("dd-MMMM-yyyy");
		DateFormatter df  = new DateFormatter(tglformat);
		
		JFormattedTextField formattglahir = new JFormattedTextField(df);
		formattglahir.setBounds(352, 197, 160, 20);
		formattglahir.setValue(new Date());
		formattglahir.setEditable(false);
		contentPane.add(formattglahir);
		
		java.util.Date dateTime = new java.util.Date();
		String nol_jam = "", nol_menit = "",nol_detik = "";
		int nilai_jam = dateTime.getHours();
		int nilai_menit = dateTime.getMinutes();
		int nilai_detik = dateTime.getSeconds();

		if(nilai_jam <= 9)  nol_jam= "0";
		if(nilai_menit <= 9) nol_menit= "0";
		if(nilai_detik <= 9) nol_detik= "0";
		
		String jam = nol_jam + Integer.toString(nilai_jam);
		String menit = nol_menit + Integer.toString(nilai_menit);
		String detik = nol_detik + Integer.toString(nilai_detik);
		
		textField_3.setText(jam+":"+menit+":"+detik+"");
		textField_3.setEditable(false);
		
		
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				 String id_transaksi  = textField.getText();
				 String status_barang  = comboBox.getSelectedItem().toString();;
				 String tgl_transaksi  = formattglahir.getText();
				 String jam_transaksi  = textField_3.getText();
				try{
					db.UpdateStatus(id_transaksi, status_barang, tgl_transaksi, jam_transaksi);
				try{
					model.getDataVector().removeAllElements();
					tampil();
					textField.setText("");
					comboBox.setSelectedIndex(0);
				}catch (ClassNotFoundException e1){
					e1.printStackTrace();
				}
				}catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		});
		
		
		String[] judul ={"ID Transaksi","Status Barang","Tanggal Transaksi","Jam Transaksi","Kota Dari","Kota Tujuan"};
		table = new JTable(){
			public boolean isCellEditable(int rowIndex, int colIndex) 
			{
				return false;
			}
		};
		
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) 
			{
				int pilih = table.getSelectedRow();
				if(pilih == -1)
				{
					return;
				}
				
				comboBox.setEditable(true);
				String id_transaksi = (String) model.getValueAt(pilih, 0);
				textField.setText(id_transaksi);
				String status_barang = (String) model.getValueAt(pilih, 1);
				comboBox.setSelectedItem(status_barang);
			}
		});
		model = new DefaultTableModel(null,judul);
		table.setModel(model);
		table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		table.getColumnModel().getColumn(0).setPreferredWidth(50);
		table.getColumnModel().getColumn(1).setPreferredWidth(150);
		table.getColumnModel().getColumn(2).setPreferredWidth(100);
		table.getColumnModel().getColumn(3).setPreferredWidth(100);
		
		tampil();
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(64, 321, 574, 130);
		scrollPane.setVisible(true);
		contentPane.add(scrollPane);
		scrollPane.setViewportView(table);
		
		
		
	}
	
	
	public void tampil() throws ClassNotFoundException, SQLException{
		databaseupdateStatus db = new databaseupdateStatus();
		db.opendb();
		ResultSet rs = db.gettransaksi();
		while(rs.next()){
			String id_transaksi = rs.getString(1);
			String status_barang = rs.getString(5);
			String tanggal_transaksi = rs.getString(3);
			String jam_transaksi = rs.getString(4);
			String kota_dari = rs.getString(14);
			String kota_tujuan = rs.getString(15);
			String[] row ={id_transaksi,status_barang,tanggal_transaksi,jam_transaksi,kota_dari,kota_tujuan};
			model.addRow(row);
		}
		rs.close();
	}
}

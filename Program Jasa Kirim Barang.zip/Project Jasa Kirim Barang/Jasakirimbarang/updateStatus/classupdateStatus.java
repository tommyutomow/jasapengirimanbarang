package updateStatus;

public class classupdateStatus {
	private String id_transaksi;
	private String Status_Barang;
	private String tgl_transaksi;
	private String jam_transaksi;
	
	
	public String getId_transaksi() {
		return id_transaksi;
	}
	public void setId_transaksi(String id_transaksi) {
		this.id_transaksi = id_transaksi;
	}
	public String getStatus_Barang() {
		return Status_Barang;
	}
	public void setStatus_Barang(String status_Barang) {
		Status_Barang = status_Barang;
	}
	public String getTgl_transaksi() {
		return tgl_transaksi;
	}
	public void setTgl_transaksi(String tgl_transaksi) {
		this.tgl_transaksi = tgl_transaksi;
	}
	public String getJam_transaksi() {
		return jam_transaksi;
	}
	public void setJam_transaksi(String jam_transaksi) {
		this.jam_transaksi = jam_transaksi;
	}
	
}

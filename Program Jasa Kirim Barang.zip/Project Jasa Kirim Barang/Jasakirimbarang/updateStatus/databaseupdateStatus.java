package updateStatus;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.swing.JOptionPane;

import paketReguler.classpaketReguler;

public class databaseupdateStatus {

	private Connection conn = null;
	static final String driver = "com.mysql.jdbc.Driver";
	static final String db_url = "jdbc:mysql://localhost:3306/jasakirimbarang";
	static final String username = "root";
	static final String password= "";
	
	public databaseupdateStatus() throws ClassNotFoundException{
		Class.forName(driver);
	}
	
	public void opendb() throws SQLException{
		conn = DriverManager.getConnection(db_url,username,password);
	}
	
	public void closedb() throws SQLException{
		if(conn!=null) conn.close();
	}
	
	public ResultSet gettransaksi() throws SQLException{
		opendb();
		Statement stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery("SELECT * FROM transaksi where Status_Barang NOT IN ('Delivered')");
		return rs;
	}
	
	public ArrayList<classupdateStatus> getstatus() throws SQLException{
		opendb();
		Statement stmt = conn.createStatement();
		ResultSet rs  = stmt.executeQuery("SELECT * FROM transaksi ORDER BY ID_Transaksi ASC");
		
		ArrayList<classupdateStatus> arr = new ArrayList<classupdateStatus>();
		while (rs.next()){
			classupdateStatus status_barang = new classupdateStatus();
			status_barang.setStatus_Barang(rs.getString(5));
			arr.add(status_barang);
		}
		return arr;
	}
	
	

	
	public void UpdateStatus(String id_transaksi, String status_barang, String tgl_transaksi, String jam_transaksi) throws SQLException{
		
		opendb();
		String query = "UPDATE transaksi SET Status_Barang=?, Tgl_Transaksi=?, Jam_Transaksi=?  WHERE ID_Transaksi = ? ";
		PreparedStatement ps = conn.prepareStatement(query);
			ps.setString(1, status_barang);
			ps.setString(2,tgl_transaksi );
			ps.setString(3, jam_transaksi);

			ps.setString(4, id_transaksi);
			
			conn.setAutoCommit(false);
			int result = ps.executeUpdate();
			if(result == 1){
				JOptionPane.showMessageDialog(null, "Data telah diupdate");
				conn.commit();
				}else{
					JOptionPane.showMessageDialog(null, "Data gagal disimpan");
				}
		closedb();
		
	}
	

}

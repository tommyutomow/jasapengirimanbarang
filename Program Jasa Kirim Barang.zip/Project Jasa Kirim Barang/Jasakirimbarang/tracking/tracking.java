package tracking;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import tracking.databasetracking;
import tracking.classtracking;

import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class tracking extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;

	private Connection conn = null;
	//private int a = 0;
	static final String driver = "com.mysql.jdbc.Driver";
	static final String db_url = "jdbc:mysql://localhost:3306/jasakirimbarang";
	static final String username = "root";
	static final String password= "";
	private JTextField textField_4;
	
	public void opendb() throws SQLException{
		conn = DriverManager.getConnection(db_url,username,password);
	}
	public void closedb() throws SQLException{
		if(conn!=null) conn.close();
	}
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					tracking frame = new tracking();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * @throws ClassNotFoundException 
	 * @throws SQLException 
	 */
	public tracking() throws ClassNotFoundException, SQLException {
		super("Tracking");
		databasetracking db =new databasetracking();
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 500, 500);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		Dimension frameSize = getSize();
		setLocation(
		(screenSize.width - frameSize.width) / 2,
		(screenSize.height - frameSize.height) / 2);
		
		JLabel label = new JLabel("Flash ");
		label.setHorizontalAlignment(SwingConstants.RIGHT);
		label.setForeground(new Color(255, 102, 0));
		label.setFont(new Font("Clarendon Blk BT", Font.BOLD | Font.ITALIC, 60));
		label.setBounds(-96, 0, 369, 73);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("Express");
		label_1.setForeground(Color.BLUE);
		label_1.setFont(new Font("Clarendon Blk BT", Font.BOLD, 30));
		label_1.setBounds(271, 2, 317, 71);
		contentPane.add(label_1);
		
		textField = new JTextField();
		textField.setBounds(246, 110, 118, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("ID Transaksi :");
		lblNewLabel.setFont(new Font("Arial Black", Font.PLAIN, 13));
		lblNewLabel.setBounds(120, 103, 118, 31);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Tanggal :");
		lblNewLabel_1.setFont(new Font("Arial Black", Font.PLAIN, 13));
		lblNewLabel_1.setBounds(120, 210, 75, 30);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Jam :");
		lblNewLabel_2.setFont(new Font("Arial Black", Font.PLAIN, 13));
		lblNewLabel_2.setBounds(120, 260, 75, 30);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Status :");
		lblNewLabel_3.setFont(new Font("Arial Black", Font.PLAIN, 13));
		lblNewLabel_3.setBounds(120, 310, 60, 30);
		contentPane.add(lblNewLabel_3);
		
		textField_1 = new JTextField();
		textField_1.setHorizontalAlignment(SwingConstants.CENTER);
		textField_1.setBounds(246, 217, 120, 20);
		textField_1.setEditable(false);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setHorizontalAlignment(SwingConstants.CENTER);
		textField_2.setColumns(10);
		textField_2.setBounds(244, 267, 120, 20);
		textField_2.setEditable(false);
		contentPane.add(textField_2);
		
		textField_3 = new JTextField();
		textField_3.setHorizontalAlignment(SwingConstants.CENTER);
		textField_3.setColumns(10);
		textField_3.setBounds(244, 317, 120, 20);
		textField_3.setEditable(false);
		contentPane.add(textField_3);
		
		JButton btnSearch = new JButton("Search");
		btnSearch.setFont(new Font("Arial Black", Font.PLAIN, 13));
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String idtransaksi  = textField.getText();
					try {
						opendb();
						Statement stmt = conn.createStatement();
						//ResultSet rs = stmt.executeQuery("SELECT ID_Transaksi, Tgl_Transaksi, Jam_Transaksi, Status_Barang FROM transaksi where ID_Transaksi='"+idtransaksi+"'");
						ResultSet rs = stmt.executeQuery("SELECT * FROM transaksi where ID_Transaksi='"+idtransaksi+"'");
						
							while (rs.next()) {
								String tgl = rs.getString("Tgl_Transaksi");
								String jam = rs.getString("Jam_Transaksi");
								String stat = rs.getString("Status_Barang");
								String pkt = rs.getString("Paket");
								
								textField_1.setText(tgl);
								textField_2.setText(jam);
								textField_3.setText(stat);
								textField_4.setText(pkt);
								
							}
							
					
						closedb();
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
				
}
		});
		btnSearch.setBounds(182, 157, 118, 30);
		contentPane.add(btnSearch);
		
		JLabel lblPaket = new JLabel("Paket :");
		lblPaket.setFont(new Font("Arial Black", Font.PLAIN, 13));
		lblPaket.setBounds(120, 360, 60, 30);
		contentPane.add(lblPaket);
		
		textField_4 = new JTextField();
		textField_4.setHorizontalAlignment(SwingConstants.CENTER);
		textField_4.setColumns(10);
		textField_4.setBounds(246, 367, 120, 20);
		textField_4.setEditable(false);
		contentPane.add(textField_4);

	}
}

package tracking;

public class classtracking {

	private String idtransaksi;
	private String tgltransaksi;
	private String jamtransaksi;
	private String statusbarang;
	private String paket;
	
	public String getIdtransaksi() {
		return idtransaksi;
	}
	public void setIdtransaksi(String idtransaksi) {
		this.idtransaksi = idtransaksi;
	}
	public String getTgltransaksi() {
		return tgltransaksi;
	}
	public void setTgltransaksi(String tgltransaksi) {
		this.tgltransaksi = tgltransaksi;
	}
	public String getJamtransaksi() {
		return jamtransaksi;
	}
	public void setJamtransaksi(String jamtransaksi) {
		this.jamtransaksi = jamtransaksi;
	}
	public String getStatusbarang() {
		return statusbarang;
	}
	public void setStatusbarang(String statusbarang) {
		this.statusbarang = statusbarang;
	}
	public String getPaket() {
		return paket;
	}
	public void setPaket(String paket) {
		this.paket = paket;
	}
}

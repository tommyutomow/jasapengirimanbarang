package tracking;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class databasetracking {
	private Connection conn = null;
	static final String driver = "com.mysql.jdbc.Driver";
	static final String db_url = "jdbc:mysql://localhost:3306/jasakirimbarang";
	static final String username = "root";
	static final String password= "";
	
	public databasetracking() throws ClassNotFoundException{
		Class.forName(driver);
	}
	
	public void opendb() throws SQLException{
		conn = DriverManager.getConnection(db_url,username,password);
	}
	
	public void closedb() throws SQLException{
		if(conn!=null) conn.close();
	}
	
	
	public ResultSet getTracking() throws SQLException{
		opendb();
		Statement stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery("SELECT * FROM transaksi");
		return rs;
	}
	
	
}

package paketyes;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import java.awt.Font;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.SwingConstants;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTable;
import javax.swing.JList;
import javax.swing.JTextArea;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JScrollBar;
import java.awt.Scrollbar;
import java.awt.Toolkit;
import java.awt.ScrollPane;
import javax.swing.JScrollPane;

public class paketyesinterface extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTable table;
	private DefaultTableModel model;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					paketyesinterface frame = new paketyesinterface();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * @throws ClassNotFoundException 
	 * @throws SQLException 
	 */
	public paketyesinterface() throws ClassNotFoundException, SQLException {
		super("Master Paket YES");
		
		DatabasepaketYes db =new DatabasepaketYes();
		//db.opendb();
		ArrayList<ClasspaketYes> arrkotatujuan = new ArrayList<ClasspaketYes>();
		arrkotatujuan = db.getkotatujuan();
		ArrayList<ClasspaketYes> arrkotadari = new ArrayList<ClasspaketYes>();
		arrkotadari = db.getkotadari();
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 700, 500);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		Dimension frameSize = getSize();
		setLocation(
		(screenSize.width - frameSize.width) / 2,
		(screenSize.height - frameSize.height) / 2);
		
		
		JLabel lblNewLabel = new JLabel("Flash ");
		lblNewLabel.setForeground(new Color(255, 102, 0));
		lblNewLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel.setFont(new Font("Clarendon Blk BT", Font.BOLD | Font.ITALIC, 60));
		lblNewLabel.setBounds(0, 0, 369, 73);
		contentPane.add(lblNewLabel);
		
		JLabel lblExpress = new JLabel("Express");
		lblExpress.setForeground(Color.BLUE);
		lblExpress.setFont(new Font("Clarendon Blk BT", Font.BOLD, 30));
		lblExpress.setBounds(367, 2, 317, 71);
		contentPane.add(lblExpress);
		
		JLabel lblNewLabel_1 = new JLabel("ID PaketOke");
		lblNewLabel_1.setFont(new Font("Arial Black", Font.PLAIN, 13));
		lblNewLabel_1.setBounds(188, 103, 113, 17);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblKotatujuan = new JLabel("Kota Dari");
		lblKotatujuan.setFont(new Font("Arial Black", Font.PLAIN, 13));
		lblKotatujuan.setBounds(188, 131, 113, 17);
		contentPane.add(lblKotatujuan);
		
		JLabel lblKotaTujuan = new JLabel("Kota Tujuan");
		lblKotaTujuan.setFont(new Font("Arial Black", Font.PLAIN, 13));
		lblKotaTujuan.setBounds(188, 159, 113, 17);
		contentPane.add(lblKotaTujuan);
		
		JLabel lblHargakg = new JLabel("Harga/kg");
		lblHargakg.setFont(new Font("Arial Black", Font.PLAIN, 13));
		lblHargakg.setBounds(188, 187, 113, 17);
		contentPane.add(lblHargakg);
		
		textField = new JTextField();
		textField.setFont(new Font("Arial", Font.PLAIN, 12));
		textField.setBounds(348, 102, 136, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setFont(new Font("Arial", Font.PLAIN, 12));
		comboBox.setBounds(348, 130, 136, 20);
		contentPane.add(comboBox);
		
		for(int i=0;i<arrkotadari.size();i++){
			comboBox.addItem(arrkotadari.get(i).getKotadari());
		 }
		
		JComboBox comboBox_1 = new JComboBox();
		comboBox_1.setFont(new Font("Arial", Font.PLAIN, 12));
		comboBox_1.setBounds(348, 158, 136, 20);
		contentPane.add(comboBox_1);
		for(int i=0;i<arrkotatujuan.size();i++){
			comboBox_1.addItem(arrkotatujuan.get(i).getKotatujuan());
		 }
		
		
		textField_1 = new JTextField();
		textField_1.setFont(new Font("Arial", Font.PLAIN, 12));
		textField_1.setColumns(10);
		textField_1.setBounds(348, 186, 136, 20);
		contentPane.add(textField_1);
		
		
		
		
		JButton btnNewButton = new JButton("Insert");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 String id_paket  = textField.getText();
				 String kotadari  = comboBox.getSelectedItem().toString();
				 String kotatujuan  = comboBox_1.getSelectedItem().toString();
				 int hargakg = (int) Double.parseDouble(textField_1.getText());
				 
				try {
					db.addPaketyes(id_paket,kotadari,kotatujuan,hargakg);
					try {
						model.getDataVector().removeAllElements(); //remove table 
						tampil();
						textField.setText("");
						textField_1.setText("");
					} catch (ClassNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnNewButton.setFont(new Font("Arial Black", Font.BOLD, 14));
		btnNewButton.setBounds(82, 406, 113, 29);
		contentPane.add(btnNewButton);
		
		JButton btnUpdate = new JButton("Update");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 String id_paket  = textField.getText();
				 String kotadari  = comboBox.getSelectedItem().toString();;
				 String kotatujuan  = comboBox_1.getSelectedItem().toString();
				 int hargakg = (int) Double.parseDouble(textField_1.getText());
				 
				try {
					db.updatePaketyes(kotadari, kotatujuan, hargakg, id_paket);
					
					
					
					model.getDataVector().removeAllElements(); //remove table 
					tampil();
					textField.setText("");
					textField_1.setText("");
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (ClassNotFoundException e1) {
					 //TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnUpdate.setFont(new Font("Arial Black", Font.BOLD, 14));
		btnUpdate.setBounds(298, 406, 113, 29);
		contentPane.add(btnUpdate);
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id_paket  = textField.getText();
				try {
					db.deletePaketyes(id_paket);
					model.getDataVector().removeAllElements(); //remove table 
					tampil();
					textField.setText("");
					textField_1.setText("");
				} catch (SQLException | ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				//model.getDataVector().removeAllElements(); //remove table 
			}
		});
		btnDelete.setFont(new Font("Arial Black", Font.BOLD, 14));
		btnDelete.setBounds(505, 406, 113, 29);
		contentPane.add(btnDelete);
		
		String[] judul ={"ID Paket Oke"," Kota Dari"," Kota Tujuan","Harga/kg"};
		table = new JTable(){
			public boolean isCellEditable(int rowIndex, int colIndex) 
			{
				return false;
			}
		};
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) 
			{
				int pilih = table.getSelectedRow();
				if(pilih == -1)
				{
					return;
				}
				comboBox_1.setEditable(true);
				comboBox.setEditable(true);
				String idpaketoke = (String) model.getValueAt(pilih, 0);
				textField.setText(idpaketoke);
				String kotadari = (String) model.getValueAt(pilih, 1);
				comboBox.setSelectedItem(kotadari);
				String kotatujuan = (String) model.getValueAt(pilih, 2);
				comboBox_1.setSelectedItem(kotatujuan);
				String hargakg = (String) model.getValueAt(pilih, 3);
				textField_1.setText(hargakg);
				
			}
		});
		model = new DefaultTableModel(null,judul);
		
		table.setModel(model);
		table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		table.getColumnModel().getColumn(0).setPreferredWidth(132);
		table.getColumnModel().getColumn(1).setPreferredWidth(132);
		table.getColumnModel().getColumn(2).setPreferredWidth(132);
		table.getColumnModel().getColumn(3).setPreferredWidth(132);


		
		tampil();
		//table.setPreferredScrollableViewportSize(new Dimension(450,63));
		//table.setFillsViewportHeight(true);
		table.setPreferredScrollableViewportSize(new Dimension(536, 119));
		table.setBounds(82, 260, 536, 119);
		contentPane.add(table);
		
		JScrollPane scrollPane = new JScrollPane(table);
		scrollPane.setBounds(82, 260, 534, 119);
		scrollPane.setVisible(true);
		contentPane.add(scrollPane);

		
	}
	
	public void tampil() throws ClassNotFoundException, SQLException{
		DatabasepaketYes db =new DatabasepaketYes();
		ResultSet rs = db.getpaketyes();
		while(rs.next()){
			String idpaketyes = rs.getString(1);
			String kotadari = rs.getString(2);
			String kotatujuan = rs.getString(3);
			String hargakg = String.valueOf(rs.getInt(4));
			String[] row ={idpaketyes,kotadari,kotatujuan,hargakg};
			model.addRow(row);
		}
		rs.close();
	}
	
}

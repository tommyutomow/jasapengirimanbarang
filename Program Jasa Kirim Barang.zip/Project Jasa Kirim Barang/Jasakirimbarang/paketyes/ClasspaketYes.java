package paketyes;

public class ClasspaketYes {
	private String idtarif;
	private String kotadari;
	private String kotatujuan;
	private int hargakg;
	
	public String getIdtarif() {
		return idtarif;
	}
	public void setIdtarif(String idtarif) {
		this.idtarif = idtarif;
	}
	public String getKotadari() {
		return kotadari;
	}
	public void setKotadari(String kotadari) {
		this.kotadari = kotadari;
	}
	public String getKotatujuan() {
		return kotatujuan;
	}
	public void setKotatujuan(String kotatujuan) {
		this.kotatujuan = kotatujuan;
	}
	public int getHargakg() {
		return hargakg;
	}
	public void setHargakg(int hargakg) {
		this.hargakg = hargakg;
	}
	

}

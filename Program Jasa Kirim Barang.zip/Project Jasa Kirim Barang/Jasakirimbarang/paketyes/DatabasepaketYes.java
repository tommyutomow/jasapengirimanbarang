package paketyes;
import java.sql.*;
import java.util.ArrayList;
public class DatabasepaketYes {
	private Connection conn = null;
	static final String driver = "com.mysql.jdbc.Driver";
	static final String db_url = "jdbc:mysql://localhost:3306/jasakirimbarang";
	static final String username = "root";
	static final String password= "";
	
	public DatabasepaketYes() throws ClassNotFoundException{
		Class.forName(driver);
	}
	
	public void opendb() throws SQLException{
		conn = DriverManager.getConnection(db_url,username,password);
	}
	
	public void closedb() throws SQLException{
		if(conn!=null) conn.close();
	}
	
	
	public ResultSet getpaketyes() throws SQLException{
		opendb();
		Statement stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery("SELECT * FROM paketyes ORDER BY ID_PaketYes ASC");
		return rs;
	}
	
	
	public ArrayList<ClasspaketYes> getkotatujuan() throws SQLException{
		opendb();
		Statement stmt = conn.createStatement();
		ResultSet rs  = stmt.executeQuery("SELECT * FROM kotatujuan ORDER BY Nama_KotaTujuan ASC");
		
		ArrayList<ClasspaketYes> arr = new ArrayList<ClasspaketYes>();
		while (rs.next()){
			ClasspaketYes kotatujuan = new ClasspaketYes();
			kotatujuan.setKotatujuan(rs.getString(2));
			arr.add(kotatujuan);
		}
		closedb();
		return arr;
	}
	public ArrayList<ClasspaketYes> getkotadari() throws SQLException{
		opendb();
		Statement stmt = conn.createStatement();
		ResultSet rs  = stmt.executeQuery("SELECT * FROM kotadari ORDER BY Nama_KotaDari ASC");
		
		ArrayList<ClasspaketYes> arr = new ArrayList<ClasspaketYes>();
		while (rs.next()){
			ClasspaketYes kotadari = new ClasspaketYes();
			kotadari.setKotadari(rs.getString(2));
			arr.add(kotadari);
		}
		closedb();
		return arr;
	}
	public void addPaketyes(String ID_PaketYes, String Kota_Dari,String Kota_Tujuan,int Hargakg) throws SQLException{
		opendb();
		String query = "INSERT INTO paketyes(ID_PaketYes, Kota_Dari, Kota_Tujuan, Hargakg) VALUES(?,?,?,?)";
		PreparedStatement ps = conn.prepareStatement(query);
		
		// Index dimulai dari 1 bukan 0. Index merepresentasikan urutan ?
		ps.setString(1, ID_PaketYes);
		ps.setString(2, Kota_Dari);
		ps.setString(3,Kota_Tujuan );
		ps.setInt(4, Hargakg);

		
		conn.setAutoCommit(false);
		int result = ps.executeUpdate();
		if(result == 1){
			//System.out.println("Insert Success!");
			conn.commit();
		}
		closedb();
	}
	public void updatePaketyes(String kotadari, String kotatujuan, int Hargakg,String ID_PaketYes) throws SQLException{
		opendb();
		String query = "UPDATE paketyes SET Kota_Dari=?, Kota_Tujuan=?, Hargakg= ?	 WHERE ID_PaketYes = ?";
		PreparedStatement ps = conn.prepareStatement(query);
		
		// Index dimulai dari 1 bukan 0. Index merepresentasikan urutan ?
		ps.setString(4, ID_PaketYes);
		ps.setString(1, kotadari);
		ps.setString(2, kotatujuan);
		ps.setInt(3, Hargakg);


		
		conn.setAutoCommit(false);
		int result = ps.executeUpdate();
		if(result == 1){
			System.out.println("Update Success!");
			conn.commit();
		}
		closedb();
	}
	public void deletePaketyes(String ID_PaketYes) throws SQLException{
		opendb();
		String query = "DELETE from paketyes WHERE ID_PaketYes = ?";
		PreparedStatement ps = conn.prepareStatement(query);
		
		// Index dimulai dari 1 bukan 0. Index merepresentasikan urutan ?
		ps.setString(1, ID_PaketYes);

		
		conn.setAutoCommit(false);
		int result = ps.executeUpdate();
		if(result == 1){
			System.out.println("Delete Success!");
			conn.commit();
		}
		closedb();
	}
	
}

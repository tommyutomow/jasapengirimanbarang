package cekharga;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import paketoke.DatabasepaketOke;
import paketoke.classpaketOke;
import transaksi.classtransaksi;

import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.SwingConstants;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.awt.event.ActionEvent;

public class cekharga extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	
	private Connection conn = null;
	//private int a = 0;
	static final String driver = "com.mysql.jdbc.Driver";
	static final String db_url = "jdbc:mysql://localhost:3306/jasakirimbarang";
	static final String username = "root";
	static final String password= "";
	
	public void opendb() throws SQLException{
		conn = DriverManager.getConnection(db_url,username,password);
	}
	public void closedb() throws SQLException{
		if(conn!=null) conn.close();
	}
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					cekharga frame = new cekharga();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * @throws ClassNotFoundException 
	 * @throws SQLException 
	 */
	public cekharga() throws ClassNotFoundException, SQLException {
		
		super("Cek Harga");
		
		databasecekharga db =new databasecekharga();
		//db.opendb();
		ArrayList<classcekharga> arrkotatujuan = new ArrayList<classcekharga>();
		arrkotatujuan = db.getkotatujuan();
		ArrayList<classcekharga> arrkotadari = new ArrayList<classcekharga>();
		arrkotadari = db.getkotadari();
		
		
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 500, 400);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		Dimension frameSize = getSize();
		setLocation(
		(screenSize.width - frameSize.width) / 2,
		(screenSize.height - frameSize.height) / 2);
		
		
		JLabel label = new JLabel("Flash ");
		label.setHorizontalAlignment(SwingConstants.RIGHT);
		label.setForeground(new Color(255, 102, 0));
		label.setFont(new Font("Clarendon Blk BT", Font.BOLD | Font.ITALIC, 60));
		label.setBounds(0, 0, 258, 65);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("Express");
		label_1.setForeground(Color.BLUE);
		label_1.setFont(new Font("Clarendon Blk BT", Font.BOLD, 30));
		label_1.setBounds(254, 1, 232, 71);
		contentPane.add(label_1);
		
		JLabel label_2 = new JLabel("Kota Dari");
		label_2.setFont(new Font("Arial Black", Font.PLAIN, 13));
		label_2.setBounds(56, 86, 113, 17);
		contentPane.add(label_2);
		
		JLabel label_3 = new JLabel("Kota Tujuan");
		label_3.setFont(new Font("Arial Black", Font.PLAIN, 13));
		label_3.setBounds(54, 121, 113, 17);
		contentPane.add(label_3);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setFont(new Font("Arial", Font.PLAIN, 12));
		comboBox.setBounds(254, 83, 136, 20);
		contentPane.add(comboBox);
		for(int i=0;i<arrkotadari.size();i++){
			comboBox.addItem(arrkotadari.get(i).getKotadari());
		 }
		
		JComboBox comboBox_1 = new JComboBox();
		comboBox_1.setFont(new Font("Arial", Font.PLAIN, 12));
		comboBox_1.setBounds(254, 120, 136, 20);
		contentPane.add(comboBox_1);
		for(int i=0;i<arrkotatujuan.size();i++){
			comboBox_1.addItem(arrkotatujuan.get(i).getKotatujuan());
		 }
		
		JLabel lblHargakgPaketOke = new JLabel("Harga/kg paket Oke");
		lblHargakgPaketOke.setFont(new Font("Arial Black", Font.PLAIN, 13));
		lblHargakgPaketOke.setBounds(56, 232, 156, 17);
		contentPane.add(lblHargakgPaketOke);
		
		textField = new JTextField();
		textField.setFont(new Font("Arial", Font.PLAIN, 12));
		textField.setColumns(10);
		textField.setBounds(261, 231, 136, 20);
		textField.setEditable(false);
		contentPane.add(textField);
		
		JLabel lblHargakgPaketRegular = new JLabel("Harga/kg paket Regular");
		lblHargakgPaketRegular.setFont(new Font("Arial Black", Font.PLAIN, 13));
		lblHargakgPaketRegular.setBounds(56, 267, 190, 17);
		contentPane.add(lblHargakgPaketRegular);
		
		textField_1 = new JTextField();
		textField_1.setFont(new Font("Arial", Font.PLAIN, 12));
		textField_1.setColumns(10);
		textField_1.setBounds(261, 266, 136, 20);
		textField_1.setEditable(false);
		contentPane.add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setFont(new Font("Arial", Font.PLAIN, 12));
		textField_2.setColumns(10);
		textField_2.setBounds(261, 297, 136, 20);
		textField_2.setEditable(false);
		contentPane.add(textField_2);
		
		JLabel lblHargakgPaketYes = new JLabel("Harga/kg paket Yes");
		lblHargakgPaketYes.setFont(new Font("Arial Black", Font.PLAIN, 13));
		lblHargakgPaketYes.setBounds(56, 298, 190, 17);
		contentPane.add(lblHargakgPaketYes);
		
		JButton btnSearch = new JButton("Cek Harga");
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String kotadari  = comboBox.getSelectedItem().toString();
				String kotatujuan  = comboBox_1.getSelectedItem().toString();
					try {
						opendb();
						Statement stmt = conn.createStatement();
						ResultSet rs = stmt.executeQuery("SELECT * FROM paketoke where Kota_Dari='"+kotadari+"' and Kota_Tujuan='"+kotatujuan+"'");
						
						while(rs.next()){
							classtransaksi customer = new classtransaksi();
							 int a = rs.getInt("Hargakg");
							 String hasilkestring = Integer.toString(a);
							 textField.setText(hasilkestring);
						 }
						
						Statement stmt1 = conn.createStatement();
						ResultSet rs1 = stmt1.executeQuery("SELECT * FROM paketreguler where Kota_Dari='"+kotadari+"' and Kota_Tujuan='"+kotatujuan+"'");
						
						while(rs1.next()){
							classtransaksi customer = new classtransaksi();
							 int a = rs1.getInt("Hargakg");
							 String hasilkestring = Integer.toString(a);
							 textField_1.setText(hasilkestring);
						 }
						
						Statement stmt2 = conn.createStatement();
						ResultSet rs2 = stmt2.executeQuery("SELECT * FROM paketyes where Kota_Dari='"+kotadari+"' and Kota_Tujuan='"+kotatujuan+"'");
						
						while(rs2.next()){
							classtransaksi customer = new classtransaksi();
							 int a = rs2.getInt("Hargakg");
							 String hasilkestring = Integer.toString(a);
							 textField_2.setText(hasilkestring);
						 }
						rs.close();
						rs1.close();
						rs2.close();
						closedb();
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
				
}
		});
		btnSearch.setFont(new Font("Arial Black", Font.BOLD, 14));
		btnSearch.setBounds(56, 167, 167, 29);
		contentPane.add(btnSearch);
	}
}

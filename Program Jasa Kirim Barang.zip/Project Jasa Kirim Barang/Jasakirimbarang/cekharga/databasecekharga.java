package cekharga;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import paketoke.classpaketOke;

public class databasecekharga {
	private Connection conn = null;
	static final String driver = "com.mysql.jdbc.Driver";
	static final String db_url = "jdbc:mysql://localhost:3306/jasakirimbarang";
	static final String username = "root";
	static final String password= "";
	
	public databasecekharga() throws ClassNotFoundException{
		Class.forName(driver);
	}
	
	public void opendb() throws SQLException{
		conn = DriverManager.getConnection(db_url,username,password);
	}
	
	public void closedb() throws SQLException{
		if(conn!=null) conn.close();
	}
	
	public ArrayList<classcekharga> getkotatujuan() throws SQLException{
		opendb();
		Statement stmt = conn.createStatement();
		ResultSet rs  = stmt.executeQuery("SELECT * FROM kotatujuan ORDER BY Nama_KotaTujuan ASC");
		
		ArrayList<classcekharga> arr = new ArrayList<classcekharga>();
		while (rs.next()){
			classcekharga kotatujuan = new classcekharga();
			kotatujuan.setKotatujuan(rs.getString(2));
			arr.add(kotatujuan);
		}
		closedb();
		return arr;
	}
	public ArrayList<classcekharga> getkotadari() throws SQLException{
		opendb();
		Statement stmt = conn.createStatement();
		ResultSet rs  = stmt.executeQuery("SELECT * FROM kotadari ORDER BY Nama_KotaDari ASC");
		
		ArrayList<classcekharga> arr = new ArrayList<classcekharga>();
		while (rs.next()){
			classcekharga kotadari = new classcekharga();
			kotadari.setKotadari(rs.getString(2));
			arr.add(kotadari);
		}
		closedb();
		return arr;
	}
}

package cekharga;

public class classcekharga {
	private String kotadari;
	private String kotatujuan;
	private String hargapaketoke;
	private String hargapaketyes;
	private String hargapaketregular;
	public String getKotadari() {
		return kotadari;
	}
	public void setKotadari(String kotadari) {
		this.kotadari = kotadari;
	}
	public String getKotatujuan() {
		return kotatujuan;
	}
	public void setKotatujuan(String kotatujuan) {
		this.kotatujuan = kotatujuan;
	}
	public String getHargapaketoke() {
		return hargapaketoke;
	}
	public void setHargapaketoke(String hargapaketoke) {
		this.hargapaketoke = hargapaketoke;
	}
	public String getHargapaketyes() {
		return hargapaketyes;
	}
	public void setHargapaketyes(String hargapaketyes) {
		this.hargapaketyes = hargapaketyes;
	}
	public String getHargapaketregular() {
		return hargapaketregular;
	}
	public void setHargapaketregular(String hargapaketregular) {
		this.hargapaketregular = hargapaketregular;
	}
	
}

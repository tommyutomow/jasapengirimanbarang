package pegawai;

import java.sql.*;
import java.util.ArrayList;

import pegawai.ClassPegawai;


public class DatabasePegawai {

	private Connection conn = null;
	static final String driver = "com.mysql.jdbc.Driver";
	static final String db_url = "jdbc:mysql://localhost:3306/jasakirimbarang";
	static final String username = "root";
	static final String password= "";
	
	public DatabasePegawai() throws ClassNotFoundException{
		Class.forName(driver);
	}
	
	public void opendb() throws SQLException{
		conn = DriverManager.getConnection(db_url,username,password);
	}
	
	public void closedb() throws SQLException{
		if(conn!=null) conn.close();
	}
	
	
	public ResultSet getpPegawai() throws SQLException{
		opendb();
		Statement stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery("SELECT * FROM pegawai ORDER BY ID_Pegawai ASC");
		return rs;
	}
	
	
	public void addPegawai(String ID_Pegawai, String Nama,String Telepon,String Username, String Password, String Hak_User) throws SQLException{
		opendb();
		String query = "INSERT INTO pegawai(ID_Pegawai, Nama, Telepon, Username, Password, Hak_User) VALUES(?,?,?,?,?,?)";
		PreparedStatement ps = conn.prepareStatement(query);
		
		// Index dimulai dari 1 bukan 0. Index merepresentasikan urutan ?
		ps.setString(1, ID_Pegawai);
		ps.setString(2, Nama);
		ps.setString(3,Telepon );
		ps.setString(4, Username);
		ps.setString(5, Password);
		ps.setString(6, Hak_User);

		
		conn.setAutoCommit(false);
		int result = ps.executeUpdate();
		if(result == 1){
			System.out.println("Insert Success!");
			conn.commit();
		}
		closedb();
	}
	
	public void updatePegawai(String Nama, String Telepon, String Username, String Password, String Hak_User, String ID_Pegawai) throws SQLException{
		opendb();
		String query = "UPDATE pegawai SET Nama=?, Telepon=?, Username= ?, Password= ?, Hak_User = ? WHERE ID_Pegawai = ?";
		PreparedStatement ps = conn.prepareStatement(query);
		
		// Index dimulai dari 1 bukan 0. Index merepresentasikan urutan ?
		ps.setString(6, ID_Pegawai);
		ps.setString(1, Nama);
		ps.setString(2, Telepon);
		ps.setString(3, Username);
		ps.setString(4, Password);
		ps.setString(5, Hak_User);
		
		conn.setAutoCommit(false);
		int result = ps.executeUpdate();
		if(result == 1){
			System.out.println("Update Success!");
			conn.commit();
		}
		closedb();
	}
	
	public void deletePegawai(String ID_Pegawai) throws SQLException{
		opendb();
		String query = "DELETE from pegawai WHERE ID_Pegawai = ?";
		PreparedStatement ps = conn.prepareStatement(query);
		
		// Index dimulai dari 1 bukan 0. Index merepresentasikan urutan ?
		ps.setString(1, ID_Pegawai);

		
		conn.setAutoCommit(false);
		int result = ps.executeUpdate();
		if(result == 1){
			System.out.println("Delete Success!");
			conn.commit();
		}
		closedb();
	}
	
}

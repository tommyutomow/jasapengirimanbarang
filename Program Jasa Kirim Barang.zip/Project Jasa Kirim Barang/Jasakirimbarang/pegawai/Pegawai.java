package pegawai;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import pegawai.DatabasePegawai;

import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JTable;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import javax.swing.JPasswordField;
import javax.swing.JComboBox;

public class Pegawai extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JPasswordField textField_4;
	private JTable table;
	private DefaultTableModel model;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Pegawai frame = new Pegawai();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * @throws ClassNotFoundException 
	 * @throws SQLException 
	 */
	public Pegawai() throws ClassNotFoundException, SQLException {
		super("Master Pegawai");
		
		DatabasePegawai db = new DatabasePegawai();
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 1000, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		Dimension frameSize = getSize();
		setLocation(
		(screenSize.width - frameSize.width) / 2,
		(screenSize.height - frameSize.height) / 2);
		
		
		JLabel lblNewLabel = new JLabel("FLASH");
		lblNewLabel.setBounds(300, 10, 245, 73);
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setForeground(new Color(255, 102, 0));
		lblNewLabel.setFont(new Font("Clarendon Blk BT", Font.BOLD | Font.ITALIC, 60));
		contentPane.add(lblNewLabel);
		
		JLabel lblExpress = new JLabel("Express");
		lblExpress.setBounds(546, 37, 160, 40);
		lblExpress.setForeground(Color.BLUE);
		lblExpress.setFont(new Font("Clarendon Blk BT", Font.PLAIN, 30));
		contentPane.add(lblExpress);
		
		textField = new JTextField();
		textField.setBounds(225, 170, 185, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(225, 220, 185, 20);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(225, 270, 185, 20);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setBounds(225, 320, 185, 20);
		contentPane.add(textField_3);
		textField_3.setColumns(10);
		
		textField_4 = new JPasswordField();
		textField_4.setBounds(225, 370, 185, 20);
		contentPane.add(textField_4);
		textField_4.setColumns(10);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Admin","Pegawai"}));
		comboBox.setBounds(225, 420, 185, 20);
		contentPane.add(comboBox);
		
		JLabel lblNewLabel_1 = new JLabel("ID Pegawai :");
		lblNewLabel_1.setFont(new Font("Arial Black", Font.PLAIN, 14));
		lblNewLabel_1.setBounds(54, 170, 96, 17);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNama = new JLabel("Nama :");
		lblNama.setFont(new Font("Arial Black", Font.PLAIN, 14));
		lblNama.setBounds(54, 221, 96, 14);
		contentPane.add(lblNama);
		
		JLabel lblTelepon = new JLabel("Telepon :");
		lblTelepon.setFont(new Font("Arial Black", Font.PLAIN, 14));
		lblTelepon.setBounds(54, 271, 86, 14);
		contentPane.add(lblTelepon);
		
		JLabel lblUsername = new JLabel("Username :");
		lblUsername.setFont(new Font("Arial Black", Font.PLAIN, 14));
		lblUsername.setBounds(54, 321, 96, 14);
		contentPane.add(lblUsername);
		
		JLabel lblPassword = new JLabel("Password :");
		lblPassword.setFont(new Font("Arial Black", Font.PLAIN, 14));
		lblPassword.setBounds(54, 371, 86, 14);
		contentPane.add(lblPassword);
		
		JLabel lblHakUser = new JLabel("Hak User :");
		lblHakUser.setFont(new Font("Arial Black", Font.PLAIN, 14));
		lblHakUser.setBounds(54, 421, 86, 14);
		contentPane.add(lblHakUser);
		
		JButton btnInsert = new JButton("INSERT");
		btnInsert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String id_pegawai  = textField.getText();
				String nama  = textField_1.getText();
				String telepon  = textField_2.getText();
				String username  = textField_3.getText();
				String password  = textField_4.getText();
				String hakuser = comboBox.getSelectedItem().toString();
				
				
				try {
					db.addPegawai(id_pegawai, nama, telepon, username, password, hakuser);
					try {
						model.getDataVector().removeAllElements(); //remove table 
						tampil();
						textField.setText("");
						textField_1.setText("");
						textField_2.setText("");
						textField_3.setText("");
						textField_4.setText("");
						comboBox.setSelectedIndex(0);
					} catch (ClassNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});


	
		String[] judul ={"ID Pegawai"," Nama"," Telepon","Username","Password","Hak User"};
		table = new JTable(){
			public boolean isCellEditable(int rowIndex, int colIndex) 
			{
				return false;
			}
		};
		
		btnInsert.setFont(new Font("Arial Black", Font.PLAIN, 14));
		btnInsert.setBounds(54, 471, 99, 34);
		contentPane.add(btnInsert);
		
		JButton btnUpdate = new JButton("UPDATE");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 String id_pegawai  = textField.getText();
				 String nama  = textField_1.getText();
				 String telepon  = textField_2.getText();
				 String username = textField_3.getText();
				 String password = textField_4.getText();
				 String hakuser = comboBox.getSelectedItem().toString();
				 
				try {
					db.updatePegawai(nama,telepon,username,password,hakuser,id_pegawai);
	
					model.getDataVector().removeAllElements(); //remove table 
					tampil();
					textField.setText("");
					textField_1.setText("");
					textField_2.setText("");
					textField_3.setText("");
					textField_4.setText("");
					comboBox.setSelectedIndex(0);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (ClassNotFoundException e1) {
					 //TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnUpdate.setFont(new Font("Arial Black", Font.PLAIN, 14));
		btnUpdate.setBounds(177, 471, 104, 34);
		contentPane.add(btnUpdate);
		
		JButton btnDelete = new JButton("DELETE");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
					String id_pegawai  = textField.getText();
					try {
						db.deletePegawai(id_pegawai);
						model.getDataVector().removeAllElements(); //remove table 
						tampil();
						textField.setText("");
						textField_1.setText("");
						textField_2.setText("");
						textField_3.setText("");
						textField_4.setText("");
						comboBox.setSelectedIndex(0);
					} catch (SQLException | ClassNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					//model.getDataVector().removeAllElements(); //remove table 
				}
			});

		btnDelete.setFont(new Font("Arial Black", Font.PLAIN, 14));
		btnDelete.setBounds(300, 471, 109, 34);
		contentPane.add(btnDelete);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(429, 166, 533, 220);
		contentPane.add(scrollPane);
		
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) 
			{
				int pilih = table.getSelectedRow();
				if(pilih == -1)
				{
					return;
				}
	
				String idpegawai = (String) model.getValueAt(pilih, 0);
				textField.setText(idpegawai);
				String nama = (String) model.getValueAt(pilih, 1);
				textField_1.setText(nama);
				String telepon = (String) model.getValueAt(pilih, 2);
				textField_2.setText(telepon);
				String username = (String) model.getValueAt(pilih, 3);
				textField_3.setText(username);
				String password = (String) model.getValueAt(pilih, 4);
				textField_4.setText(password);
			}
		});
		
		model = new DefaultTableModel(null,judul);
		
		table.setModel(model);
		table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		table.getColumnModel().getColumn(1).setPreferredWidth(60);
		table.getColumnModel().getColumn(2).setPreferredWidth(100);
		table.getColumnModel().getColumn(3).setPreferredWidth(100);
		table.getColumnModel().getColumn(4).setPreferredWidth(100);
		table.getColumnModel().getColumn(5).setPreferredWidth(100);
		
		tampil();
		table.setModel(model);
		
		scrollPane.setViewportView(table);
		
		

	}
	
	private void tampil() throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		DatabasePegawai db =new DatabasePegawai();
		ResultSet rs = db.getpPegawai();
		while(rs.next()){
			String idpegawai = rs.getString(1);
			String nama = rs.getString(2);
			String telepon = rs.getString(3);
			String username = rs.getString(4);
			String password = rs.getString(5);
			String hakuser = rs.getString(6);
			String[] row ={idpegawai,nama,telepon,username,password,hakuser};
			model.addRow(row);
		}
		rs.close();
	}
}

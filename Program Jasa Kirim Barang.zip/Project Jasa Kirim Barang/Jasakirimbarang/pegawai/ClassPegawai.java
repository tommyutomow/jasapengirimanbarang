package pegawai;

public class ClassPegawai {
	private String idpegawai;
	private String nama;
	private String telepon;
	private String username;
	private String password;
	private String hakuser;
	
	public String getIdpegawai() {
		return idpegawai;
	}
	public void setIdpegawai(String idpegawai) {
		this.idpegawai = idpegawai;
	}
	public String getNama() {
		return nama;
	}
	public void setNama(String nama) {
		this.nama = nama;
	}
	public String getTelepon() {
		return telepon;
	}
	public void setTelepon(String telepon) {
		this.telepon = telepon;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getHakuser() {
		return hakuser;
	}
	public void setHakuser(String hakuser) {
		this.hakuser = hakuser;
	}
}

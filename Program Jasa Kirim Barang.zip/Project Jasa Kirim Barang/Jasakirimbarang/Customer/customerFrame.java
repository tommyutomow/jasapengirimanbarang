package Customer;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JTable;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import javax.swing.SwingConstants;

public class customerFrame extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private DefaultTableModel model;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					customerFrame frame = new customerFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * @return 
	 * @throws ClassNotFoundException 
	 * @throws SQLException 
	 */
	public  customerFrame() throws ClassNotFoundException, SQLException {
		super("Master Customer");
		databaseCustomer db = new databaseCustomer();
		db.opendb();
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 1000, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		Dimension frameSize = getSize();
		setLocation(
		(screenSize.width - frameSize.width) / 2,
		(screenSize.height - frameSize.height) / 2);
		
		
		JLabel lblFlash = new JLabel("Flash ");
		lblFlash.setHorizontalAlignment(SwingConstants.RIGHT);
		lblFlash.setForeground(new Color(255, 102, 0));
		lblFlash.setFont(new Font("Clarendon Blk BT", Font.PLAIN, 60));
		lblFlash.setBounds(0, -1, 558, 81);
		contentPane.add(lblFlash);
		
		JLabel lblExpress = new JLabel("Express");
		lblExpress.setForeground(new Color(51, 0, 153));
		lblExpress.setFont(new Font("Clarendon Blk BT", Font.PLAIN, 30));
		lblExpress.setBounds(559, 26, 427, 48);
		contentPane.add(lblExpress);
		
		JLabel lblIdCustomer = new JLabel("ID Customer :");
		lblIdCustomer.setFont(new Font("Arial Black", Font.PLAIN, 14));
		lblIdCustomer.setBounds(263, 119, 111, 21);
		contentPane.add(lblIdCustomer);
		
		textField = new JTextField();
		textField.setFont(new Font("Tahoma", Font.PLAIN, 11));
		textField.setBounds(422, 121, 279, 19);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblNama = new JLabel("Nama :");
		lblNama.setFont(new Font("Arial Black", Font.PLAIN, 14));
		lblNama.setBounds(263, 151, 111, 21);
		contentPane.add(lblNama);
		
		textField_1 = new JTextField();
		textField_1.setFont(new Font("Tahoma", Font.PLAIN, 11));
		textField_1.setColumns(10);
		textField_1.setBounds(422, 153, 279, 19);
		contentPane.add(textField_1);
		
		JLabel lblAlamat = new JLabel("Alamat :");
		lblAlamat.setFont(new Font("Arial Black", Font.PLAIN, 14));
		lblAlamat.setBounds(263, 183, 111, 21);
		contentPane.add(lblAlamat);
		
		textField_2 = new JTextField();
		textField_2.setFont(new Font("Tahoma", Font.PLAIN, 11));
		textField_2.setColumns(10);
		textField_2.setBounds(422, 185, 279, 19);
		contentPane.add(textField_2);
		
		JLabel lblTelepon = new JLabel("Telepon :");
		lblTelepon.setFont(new Font("Arial Black", Font.PLAIN, 14));
		lblTelepon.setBounds(263, 215, 111, 21);
		contentPane.add(lblTelepon);
		
		textField_3 = new JTextField();
		textField_3.setFont(new Font("Tahoma", Font.PLAIN, 11));
		textField_3.setColumns(10);
		textField_3.setBounds(422, 217, 279, 19);
		contentPane.add(textField_3);
		
		JLabel lblEmail = new JLabel("Email");
		lblEmail.setFont(new Font("Arial Black", Font.PLAIN, 14));
		lblEmail.setBounds(263, 247, 111, 21);
		contentPane.add(lblEmail);
		
		textField_4 = new JTextField();
		textField_4.setFont(new Font("Tahoma", Font.PLAIN, 11));
		textField_4.setColumns(10);
		textField_4.setBounds(422, 249, 279, 19);
		contentPane.add(textField_4);
		
		JButton btnInsert = new JButton("Insert");
		btnInsert.setFont(new Font("Arial Black", Font.PLAIN, 14));
		btnInsert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String idcustomer = textField.getText();
				String nama = textField_1.getText();
				String alamat = textField_2.getText();
				String telepon = textField_3.getText();
				String email = textField_4.getText();
				try{
					db.addCustomer(idcustomer, nama, alamat, telepon, email);
					try{
						model.getDataVector().removeAllElements();
						tampil();
						textField.setText("");
						textField_1.setText("");
						textField_2.setText("");
						textField_3.setText("");
						textField_4.setText("");
					}catch (ClassNotFoundException e1){
						e1.printStackTrace();
					}
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				
			}
		});
		btnInsert.setBounds(294, 309, 111, 37);
		contentPane.add(btnInsert);
		
		JButton btnUpdate = new JButton("Update");
		btnUpdate.setFont(new Font("Arial Black", Font.PLAIN, 14));
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String idcustomer = textField.getText();
				String nama = textField_1.getText();
				String alamat = textField_2.getText();
				String telepon = textField_3.getText();
				String email = textField_4.getText();
				try{
					db.updateCustomer(idcustomer, nama, alamat, telepon, email);
					try{
						model.getDataVector().removeAllElements();
						tampil();
						textField.setText("");
						textField_1.setText("");
						textField_2.setText("");
						textField_3.setText("");
						textField_4.setText("");
						}catch (ClassNotFoundException e1){
							e1.printStackTrace();
						}
						} catch (SQLException e1) {
								e1.printStackTrace();
						}
					
			}
		});
		btnUpdate.setBounds(452, 309, 106, 37);
		contentPane.add(btnUpdate);
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.setFont(new Font("Arial Black", Font.PLAIN, 14));
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String idcustomer = textField.getText();
				
				try{
					db.deleteCustomer(idcustomer);
					try{
						model.getDataVector().removeAllElements();
						tampil();
						textField.setText("");
						textField_1.setText("");
						textField_2.setText("");
						textField_3.setText("");
						textField_4.setText("");
					}catch (ClassNotFoundException e1){
						e1.printStackTrace();
					}
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				
			}
		});
		btnDelete.setBounds(601, 309, 100, 37);
		contentPane.add(btnDelete);
		
		String[] judul ={"ID Customer","Nama","Alamat","Telepon","Email"};
		
		table = new JTable(){
			public boolean isCellEditable(int rowIndex, int colIndex) 
			{
				return false;
			}
		};
		
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) 
			{
				int pilih = table.getSelectedRow();
				if(pilih == -1)
				{
					return;
				}
				
				String idcustomer = (String) model.getValueAt(pilih, 0);
				textField.setText(idcustomer);
				String nama = (String) model.getValueAt(pilih, 1);
				textField_1.setText(nama);
				String alamat = (String) model.getValueAt(pilih, 2);
				textField_2.setText(alamat);
				String telepon = (String) model.getValueAt(pilih, 3);
				textField_3.setText(telepon);
				String email = (String) model.getValueAt(pilih, 4);
				textField_4.setText(email);
			}
		});
		
		model = new DefaultTableModel(null,judul);
		
		table.setModel(model);
		table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		table.getColumnModel().getColumn(1).setPreferredWidth(120);
		table.getColumnModel().getColumn(2).setPreferredWidth(300);
		table.getColumnModel().getColumn(3).setPreferredWidth(150);
		table.getColumnModel().getColumn(4).setPreferredWidth(200);
		
		tampil();

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(51, 379, 874, 172);
		
		
		scrollPane.setViewportView(table);
		scrollPane.setVisible(true);
		contentPane.add(scrollPane);

			
	}
	public void tampil() throws ClassNotFoundException, SQLException{
		databaseCustomer db = new databaseCustomer();
		db.opendb();
		ResultSet rs = db.getCustomer();
		while(rs.next()){
			String idcustomer = rs.getString(1);
			String nama = rs.getString(2);
			String alamat = rs.getString(3);
			String telepon = rs.getString(4);
			String email = rs.getString(5);
			String[] row ={idcustomer,nama,alamat,telepon,email};
			model.addRow(row);
		}
		rs.close();
	}
}

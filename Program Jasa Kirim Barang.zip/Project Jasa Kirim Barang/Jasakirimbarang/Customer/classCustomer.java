package Customer;

public class classCustomer {
	private String idcustomer;
	private String nama;
	private String alamat;
	private String telepon;
	private String email;
	
	
	public String getIdcustomer() {
		return idcustomer;
	}
	public void setIdcustomer(String idcustomer) {
		this.idcustomer = idcustomer;
	}
	public String getNama() {
		return nama;
	}
	public void setNama(String nama) {
		this.nama = nama;
	}
	public String getAlamat() {
		return alamat;
	}
	public void setAlamat(String alamat) {
		this.alamat = alamat;
	}
	public String getTelepon() {
		return telepon;
	}
	public void setTelepon(String telepon) {
		this.telepon = telepon;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
}

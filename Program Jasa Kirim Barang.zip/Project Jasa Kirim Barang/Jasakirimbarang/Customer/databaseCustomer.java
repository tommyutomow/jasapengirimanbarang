package Customer;

import java.sql.*;
import java.util.ArrayList;

import javax.swing.JOptionPane;



public class databaseCustomer {
	
	private Connection conn = null;
	static final String driver = "com.mysql.jdbc.Driver";
	static final String db_url = "jdbc:mysql://localhost:3306/jasakirimbarang";
	static final String username = "root";
	static final String password= "";


public databaseCustomer() throws ClassNotFoundException {
	Class.forName(driver);
	}

public void opendb() throws SQLException{
	conn = DriverManager.getConnection(db_url,username,password);
}

public void closedb() throws SQLException{
	if(conn!=null) conn.close();
}

public ResultSet getpaketoke() throws SQLException{
	Statement stmt = conn.createStatement();
	ResultSet rs = stmt.executeQuery("SELECT * FROM paketoke");
	return rs;
}

public ResultSet getCustomer() throws SQLException{
	opendb();
	Statement stmt = conn.createStatement();
	ResultSet rs  = stmt.executeQuery("SELECT * FROM customer ORDER BY idcustomer ASC");
	
	return rs;
}

public void addCustomer(String idcustomer, String nama, String alamat, String telepon, String email) throws SQLException{
	opendb();
	String query = "INSERT INTO customer(idcustomer, nama, alamat, telepon, email) VALUES(?,?,?,?,?)";
	PreparedStatement ps = conn.prepareStatement(query);
	ps.setString(1, idcustomer);
	ps.setString(2, nama);
	ps.setString(3, alamat);
	ps.setString(4, telepon);
	ps.setString(5, email);
	
	conn.setAutoCommit(false);
	int result = ps.executeUpdate();
	if(result == 1){
		JOptionPane.showMessageDialog(null, "Data telah disimpan");
		conn.commit();
		}else{
			JOptionPane.showMessageDialog(null, "Data gagal disimpan");
		}
	closedb();
	}

public void deleteCustomer(String idcustomer) throws SQLException{
	opendb();
	String query = "Delete FROM customer WHERE idcustomer = ? ";
	PreparedStatement ps = conn.prepareStatement(query);
	ps.setString(1, idcustomer);
	
	conn.setAutoCommit(false);
	int result = ps.executeUpdate();
	if(result == 1){
		JOptionPane.showMessageDialog(null, "Data telah didelete");
		conn.commit();
		}else{
			JOptionPane.showMessageDialog(null, "Data gagal disimpan");
		}
	closedb();
}

public void updateCustomer(String idcustomer, String nama, String alamat, String telepon, String email) throws SQLException{
	opendb();
	String query = "UPDATE customer SET nama=?, alamat=?, telepon=?, email=?  WHERE idcustomer = ? ";
	PreparedStatement ps = conn.prepareStatement(query);
	//sesuai urutan diquery atas jadi nama jadi nomor 1 dan idcustomer jd no 5
	ps.setString(1, nama);
	ps.setString(2, alamat);
	ps.setString(3, telepon);
	ps.setString(4, email);
	
	ps.setString(5, idcustomer);
	
	conn.setAutoCommit(false);
	int result = ps.executeUpdate();
	if(result == 1){
		JOptionPane.showMessageDialog(null, "Data telah diupdate");
		conn.commit();
		}else{
			JOptionPane.showMessageDialog(null, "Data gagal disimpan");
		}
	closedb();
}


}
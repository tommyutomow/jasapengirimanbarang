package KotaTujuan;

import java.awt.*;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import javax.swing.JTable;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.UIManager;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;


public class KotaTujuan extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JTextField idtujuan;
	private JTextField idtujuankota;
	private DefaultTableModel model;
	private JTable table_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					KotaTujuan frame = new KotaTujuan();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * @throws ClassNotFoundException 
	 * @throws SQLException 
	 */
	public KotaTujuan() throws ClassNotFoundException, SQLException {
		super("Master Kota Tujuan");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 700, 500);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		Dimension frameSize = getSize();
		setLocation(
		(screenSize.width - frameSize.width) / 2,
		(screenSize.height - frameSize.height) / 2);
		
		
		Database database =new Database();
		database.openConnection();
		
		JLabel tujuan = new JLabel("Id Tujuan");
		tujuan.setFont(new Font("Arial Black", Font.PLAIN, 15));
		tujuan.setBounds(45, 140, 111, 28);
		contentPane.add(tujuan);
		
		JLabel kotatujuan = new JLabel("Kota Tujuan");
		kotatujuan.setFont(new Font("Arial Black", Font.PLAIN, 15));
		kotatujuan.setBounds(45, 195, 147, 28);
		contentPane.add(kotatujuan);
		
		table = new JTable();
		table.setBounds(45, 140, 111, -45);
		contentPane.add(table);
		
		JLabel lblFlash = new JLabel("Flash");
		lblFlash.setForeground(new Color(255, 102, 0));
		lblFlash.setFont(new Font("Clarendon Blk BT", Font.BOLD | Font.ITALIC, 60));
		lblFlash.setBounds(153, 11, 205, 67);
		contentPane.add(lblFlash);
		
		JLabel lblExpress = new JLabel("Express");
		lblExpress.setForeground(Color.BLUE);
		lblExpress.setVerticalAlignment(SwingConstants.BOTTOM);
		lblExpress.setFont(new Font("Clarendon Blk BT", Font.PLAIN, 30));
		lblExpress.setBounds(355, 37, 179, 37);
		contentPane.add(lblExpress);
		
		
		JButton btnInsert = new JButton("Insert");
		btnInsert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent args0) {
				String idkotatujuan  = idtujuan.getText();
				String kotatujuan = idtujuankota.getText();
			try{
				database.addKotatujuan(idkotatujuan,kotatujuan);
				try {
					model.getDataVector().removeAllElements(); //remove table 
					tampil();
					idtujuankota.setText("");
					idtujuan.setText("");
				}catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			}	
		});
		
		btnInsert.setFont(UIManager.getFont("Button.font"));
		btnInsert.setBounds(110, 409, 135, 28);
		contentPane.add(btnInsert);
		
		
		idtujuan = new JTextField();
		idtujuan.setBounds(166, 146, 444, 28);
		contentPane.add(idtujuan);
		idtujuan.setColumns(10);
		
		idtujuankota = new JTextField();
		idtujuankota.setBounds(166, 201, 444, 28);
		contentPane.add(idtujuankota);
		idtujuankota.setColumns(10);

		String[] judul ={"ID Kota Tujuan"," Kota Tujuan"};
		table = new JTable(){
			public boolean isCellEditable(int rowIndex, int colIndex) 
			{
				return false;
			}
		};
		
		table.addMouseListener(new MouseAdapter() {
		@Override
		public void mouseClicked(MouseEvent e) 
		{
			int pilih = table.getSelectedRow();
			if(pilih == -1)
			{
				return;
			}
			String idkotatujuan = (String) model.getValueAt(pilih, 0);
			idtujuan.setText(idkotatujuan);
			String kotatujuan = (String) model.getValueAt(pilih, 1);
			idtujuankota.setText(kotatujuan);
		}
	});
		model = new DefaultTableModel(null,judul);
		
		table.setModel(model);
		table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		table.getColumnModel().getColumn(0).setPreferredWidth(285);
		table.getColumnModel().getColumn(1).setPreferredWidth(285);
		
		tampil();
		
		table.setPreferredScrollableViewportSize(new Dimension(536, 119));
		table.setBounds(82, 260, 536, 119);
		contentPane.add(table);
		
		JScrollPane scroll = new JScrollPane(table);
		scroll.setBounds(45, 269, 571, 119);
		scroll.setVisible(true);
		contentPane.add(scroll);
		
		JScrollPane scrollPane = new JScrollPane();
		scroll.setColumnHeaderView(scrollPane);
		
		table_1 = new JTable();
		scrollPane.setViewportView(table_1);
		
		JButton btnNewButton_1 = new JButton("Delete");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id_kotatujuan = idtujuan.getText();
				try {
					database.deletetujuan(id_kotatujuan);
					model.getDataVector().removeAllElements(); //remove table 
					tampil();
					idtujuankota.setText("");
					idtujuan.setText("");
				} catch (SQLException | ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				//model.getDataVector().removeAllElements(); //remove table 
			}
		});
		btnNewButton_1.setBounds(423, 409, 135, 28);
		contentPane.add(btnNewButton_1);
			}
		public void tampil() throws ClassNotFoundException, SQLException{
			Database database =new Database();
			database.openConnection();
			ResultSet rs = database.getKotaTujuan();
			while(rs.next()){
				String idkotatujuan = rs.getString(1);
				String kotatujuan = rs.getString(2);
				String[] row ={idkotatujuan,kotatujuan};
				model.addRow(row);
			}
			rs.close();
		}
}
	
	

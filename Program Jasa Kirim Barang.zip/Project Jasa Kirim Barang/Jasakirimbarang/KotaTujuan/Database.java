package KotaTujuan;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.swing.JOptionPane;

public class Database {
	private Connection con = null;
	static final String DRIVER = "com.mysql.jdbc.Driver";
	static final String DB_URL = "jdbc:mysql://localhost:3306/jasakirimbarang";
	static final String USERNAME = "root";
	static final String PASSWORD = "";
	
	public Database() throws ClassNotFoundException{
		Class.forName(DRIVER);
	}
	
	public void openConnection() throws SQLException{
		con = DriverManager.getConnection(DB_URL,USERNAME,PASSWORD);
	}
	
	public void closeConnection() throws SQLException{
		if(con != null) con.close();
	}
	
	public ResultSet getKotaTujuan() throws SQLException{
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery("SELECT * FROM kotatujuan ORDER BY Nama_KotaTujuan ASC");
		return rs;
	}
	
	/*public ArrayList<Tujuan> getTujuan() throws SQLException{
		this.openConnection();
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery("SELECT * FROM kotatujuan");
		
		ArrayList<Tujuan> alTujuan = new ArrayList<Tujuan>();
		while(rs.next()){
			Tujuan tujuan = new Tujuan();
			tujuan.setID_KotaTujuan(rs.getString(1));
			tujuan.setNama_KotaTujuan(rs.getString(2));
		
			alTujuan.add(tujuan);
		}
		this.closeConnection();
		return alTujuan;
		
	}*/
	
	public void addKotatujuan(String ID_KotaTujuan, String Nama_KotaTujuan) throws SQLException{
		this.openConnection();
		String query = "INSERT INTO kotatujuan(ID_KotaTujuan, Nama_KotaTujuan) VALUES(?,?)";
		PreparedStatement ps = con.prepareStatement(query);
		
		ps.setString(1, ID_KotaTujuan);
		ps.setString(2, Nama_KotaTujuan);
		
		con.setAutoCommit(false);
		int result = ps.executeUpdate();
		if(result == 1){
			JOptionPane.showMessageDialog(null, "Insert Berhasil");
			con.commit();
		}else{
			JOptionPane.showMessageDialog(null, "Insert Gagal");
		}
	}
	public void deletetujuan(String ID_KotaTujuan) throws SQLException{
		this.openConnection();
		String query = "DELETE from kotatujuan WHERE ID_KotaTujuan = ?";
		PreparedStatement ps = con.prepareStatement(query);
		
		// Index dimulai dari 1 bukan 0. Index merepresentasikan urutan ?
		ps.setString(1, ID_KotaTujuan);

		
		con.setAutoCommit(false);
		int result = ps.executeUpdate();
		if(result == 1){
			JOptionPane.showMessageDialog(null, "Delete Berhasil");
			con.commit();
		}else{
			JOptionPane.showMessageDialog(null, "Delete Gagal");
		}
		
	}
}


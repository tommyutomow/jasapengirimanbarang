package KotaTujuan;


public class Tujuan {
		private String ID_KotaTujuan;
		private String Nama_KotaTujuan;
		
		public String getID_KotaTujuan() {
			return ID_KotaTujuan;
		}
		public void setID_KotaTujuan(String id_KotaTujuan) {
			ID_KotaTujuan = id_KotaTujuan;
		}
		public String getNama_KotaTujuan() {
			return Nama_KotaTujuan;
		}
		public void setNama_KotaTujuan(String nama_KotaTujuan) {
			Nama_KotaTujuan = nama_KotaTujuan;
		}
}

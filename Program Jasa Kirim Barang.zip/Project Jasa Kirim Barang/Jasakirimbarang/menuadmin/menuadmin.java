package menuadmin;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;
import java.awt.event.*;
import java.sql.SQLException;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JToolBar;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.ButtonGroup;
import javax.swing.event.MenuKeyListener;
import javax.swing.event.MenuKeyEvent;
import javax.swing.event.MenuListener;

import Customer.customerFrame;
import KotaTujuan.KotaTujuan;
import paketReguler.paketReguler;
import paketoke.paketokeinterface;
import paketyes.paketyesinterface;
import pegawai.Pegawai;
import transaksi.transaksi;
import updateStatus.updateStatus;
import KotaDari.KotaDari;

import javax.swing.event.MenuEvent;

public class menuadmin extends JFrame {

	private JPanel contentPane;
	private final ButtonGroup buttonGroup = new ButtonGroup();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					menuadmin frame = new menuadmin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public menuadmin() {
		super("Main Menu");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		
		
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		Dimension frameSize = getSize();
		setLocation(
		(screenSize.width - frameSize.width) / 2,
		(screenSize.height - frameSize.height) / 2);
		
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnMaster = new JMenu("Master");
		menuBar.add(mnMaster);
		
		JMenuItem mntmMasterDataCustomer = new JMenuItem("Master Data Customer");
		mntmMasterDataCustomer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					new customerFrame().setVisible(true);
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		mnMaster.add(mntmMasterDataCustomer);
		
		JMenuItem mntmMasterData = new JMenuItem("Master Data Pegawai");
		mntmMasterData.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					new Pegawai().setVisible(true);
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		mnMaster.add(mntmMasterData);
		
		JMenuItem mntmKotaTujuan = new JMenuItem("Kota Tujuan");
		mntmKotaTujuan.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					new KotaTujuan().setVisible(true);
				} catch (ClassNotFoundException | SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		mnMaster.add(mntmKotaTujuan);
		
		JMenuItem mntmKotaAsal = new JMenuItem("Kota Asal");
		mntmKotaAsal.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					new KotaDari().setVisible(true);
				} catch (ClassNotFoundException | SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		mnMaster.add(mntmKotaAsal);
		
		JMenu mnNewMenu = new JMenu("Paket");
		mnMaster.add(mnNewMenu);
		
		JMenuItem mntmPaketRegular = new JMenuItem("Paket Oke");
		mntmPaketRegular.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					new paketokeinterface().setVisible(true);
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		mnNewMenu.add(mntmPaketRegular);
		
		JMenuItem mntmPaketRegular_1 = new JMenuItem("Paket Regular");
		mntmPaketRegular_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					new paketReguler().setVisible(true);
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		mnNewMenu.add(mntmPaketRegular_1);
		
		JMenuItem mntmPaketYes = new JMenuItem("Paket Yes");
		mntmPaketYes.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					new paketyesinterface().setVisible(true);
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		mnNewMenu.add(mntmPaketYes);
		
		JMenu mnTransaksi = new JMenu("Transaksi");
		menuBar.add(mnTransaksi);
		
		JMenuItem mntmTransaksi = new JMenuItem("Transaksi");
		mntmTransaksi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					new transaksi().setVisible(true);
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		mnTransaksi.add(mntmTransaksi);
		
		JMenu mnUpdateStatus = new JMenu("Update Status");
		menuBar.add(mnUpdateStatus);
		
		JMenuItem mntmUpdateStatus = new JMenuItem("Update Status");
		mntmUpdateStatus.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					new updateStatus().setVisible(true);
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		mnUpdateStatus.add(mntmUpdateStatus);
		
		JMenu mnExit = new JMenu("Exit");
		mnExit.addMenuListener(new MenuListener() {
			public void menuCanceled(MenuEvent arg0) {
			}
			public void menuDeselected(MenuEvent arg0) {
			}
			public void menuSelected(MenuEvent arg0) {
				setVisible(false);
			}
		});
		menuBar.add(mnExit);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
	}

}

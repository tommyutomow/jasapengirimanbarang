package KotaDari;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.swing.JOptionPane;

public class Database {
	private Connection con = null;
	static final String DRIVER = "com.mysql.jdbc.Driver";
	static final String DB_URL = "jdbc:mysql://localhost:3306/jasakirimbarang";
	static final String USERNAME = "root";
	static final String PASSWORD = "";
	
	public Database() throws ClassNotFoundException{
		Class.forName(DRIVER);
	}
	
	public void openConnection() throws SQLException{
		con = DriverManager.getConnection(DB_URL,USERNAME,PASSWORD);
	}
	
	public void closeConnection() throws SQLException{
		if(con != null) con.close();
	}
	
	public ResultSet getKotaDari() throws SQLException{
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery("SELECT * FROM kotadari ORDER BY Nama_KotaDari ASC");
		return rs;
	}
	
	/*public ArrayList<Tujuan> getTujuan() throws SQLException{
		this.openConnection();
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery("SELECT * FROM kotatujuan");
		
		ArrayList<Tujuan> alTujuan = new ArrayList<Tujuan>();
		while(rs.next()){
			Tujuan tujuan = new Tujuan();
			tujuan.setID_KotaTujuan(rs.getString(1));
			tujuan.setNama_KotaTujuan(rs.getString(2));
		
			alTujuan.add(tujuan);
		}
		this.closeConnection();
		return alTujuan;
		
	}*/
	
	public void addKotadari(String ID_KotaDari, String Nama_KotaDari) throws SQLException{
		this.openConnection();
		String query = "INSERT INTO kotadari(ID_KotaDari, Nama_KotaDari) VALUES(?,?)";
		PreparedStatement ps = con.prepareStatement(query);
		
		ps.setString(1, ID_KotaDari);
		ps.setString(2, Nama_KotaDari);
		
		con.setAutoCommit(false);
		int result = ps.executeUpdate();
		if(result == 1){
			JOptionPane.showMessageDialog(null, "Insert Berhasil");
			con.commit();
		}else{
			JOptionPane.showMessageDialog(null, "Insert Gagal");
		}
	}
	public void deletedari(String ID_KotaDari) throws SQLException{
		this.openConnection();
		String query = "DELETE from kotadari WHERE ID_KotaDari = ?";
		PreparedStatement ps = con.prepareStatement(query);
		
		// Index dimulai dari 1 bukan 0. Index merepresentasikan urutan ?
		ps.setString(1, ID_KotaDari);

		
		con.setAutoCommit(false);
		int result = ps.executeUpdate();
		if(result == 1){
			JOptionPane.showMessageDialog(null, "Delete Berhasil");
			con.commit();
		}
		
	}
}


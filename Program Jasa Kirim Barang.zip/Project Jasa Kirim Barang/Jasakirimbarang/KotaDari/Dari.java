package KotaDari;

public class Dari {
	private String ID_KotaDari;
	private String Nama_KotaDari;
	
	public String getID_KotaDari() {
		return ID_KotaDari;
	}
	public void setID_KotaDari(String id_KotaDari) {
		ID_KotaDari = id_KotaDari;
	}
	public String getNama_KotaDari() {
		return Nama_KotaDari;
	}
	public void setNama_KotaDari(String nama_KotaDari) {
		Nama_KotaDari = nama_KotaDari;
	}
}

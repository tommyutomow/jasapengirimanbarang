package KotaDari;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import KotaDari.Database;

import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class KotaDari extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTable table;
	private JTable table_1;
	private DefaultTableModel model;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					KotaDari frame = new KotaDari();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * @throws ClassNotFoundException 
	 * @throws SQLException 
	 */
	public KotaDari() throws ClassNotFoundException, SQLException {
		super("Master Kota Dari");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 700, 500);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		Dimension frameSize = getSize();
		setLocation(
		(screenSize.width - frameSize.width) / 2,
		(screenSize.height - frameSize.height) / 2);
		
		
		Database database1 =new Database();
		database1.openConnection();
		
		JLabel lblFlash = new JLabel("Flash");
		lblFlash.setForeground(new Color(255, 102, 0));
		lblFlash.setFont(new Font("Clarendon Blk BT", Font.BOLD | Font.ITALIC, 60));
		lblFlash.setBounds(172, 11, 217, 73);
		contentPane.add(lblFlash);
		
		JLabel lblExpress = new JLabel("Express");
		lblExpress.setVerticalAlignment(SwingConstants.BOTTOM);
		lblExpress.setForeground(Color.BLUE);
		lblExpress.setFont(new Font("Clarendon Blk BT", Font.PLAIN, 30));
		lblExpress.setBounds(374, 49, 148, 28);
		contentPane.add(lblExpress);
		
		JLabel dari = new JLabel("Id Kota Asal");
		dari.setFont(new Font("Arial Black", Font.PLAIN, 18));
		dari.setBounds(34, 128, 141, 28);
		contentPane.add(dari);
		
		JLabel kotadari = new JLabel("Asal Kota");
		kotadari.setFont(new Font("Arial Black", Font.PLAIN, 18));
		kotadari.setBounds(34, 191, 141, 28);
		contentPane.add(kotadari);
		
		textField = new JTextField();
		textField.setBounds(185, 135, 470, 28);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(185, 198, 470, 28);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		
		String[] judul ={"ID Kota Asal"," Kota Asal"};
		table = new JTable(){
			public boolean isCellEditable(int rowIndex, int colIndex) 
			{
				return false;
			}
		};
		
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) 
			{
				int pilih = table.getSelectedRow();
				if(pilih == -1)
				{
					return;
				}
				String idkotadari = (String) model.getValueAt(pilih, 0);
				textField.setText(idkotadari);
				String kotadari = (String) model.getValueAt(pilih, 1);
				textField_1.setText(kotadari);
			}
		});
		
		model = new DefaultTableModel(null,judul);
		
		table.setModel(model);
		table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		table.getColumnModel().getColumn(0).setPreferredWidth(310);
		table.getColumnModel().getColumn(1).setPreferredWidth(310);
		
		tampil();
		
		table.setPreferredScrollableViewportSize(new Dimension(536, 119));
		table.setBounds(82, 260, 536, 119);
		contentPane.add(table);
		
		
		JScrollPane scrollpane = new JScrollPane(table);
		scrollpane.setBounds(35, 245, 620, 119);
		scrollpane.setVisible(true);
		contentPane.add(scrollpane);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollpane.setColumnHeaderView(scrollPane);
		
		table_1 = new JTable();
		scrollPane.setViewportView(table_1);
		
		JButton btnNewButton = new JButton("Insert");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent args0) {
				String idkotadari  = textField.getText();
				String kotadari = textField_1.getText();
			try{
				database1.addKotadari(idkotadari,kotadari);
				try {
					model.getDataVector().removeAllElements(); //remove table 
					tampil();
					textField.setText("");
					textField_1.setText("");
				}catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			}	
		});
		btnNewButton.setBounds(124, 388, 140, 28);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Delete");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id_kotadari = textField.getText();
				try {
					database1.deletedari(id_kotadari);
					model.getDataVector().removeAllElements(); //remove table 
					tampil();
					textField.setText("");
					textField_1.setText("");
				} catch (SQLException | ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				//model.getDataVector().removeAllElements(); //remove table 
			}
		});
		btnNewButton_1.setBounds(422, 388, 141, 28);
		contentPane.add(btnNewButton_1);
	}
	public void tampil() throws ClassNotFoundException, SQLException{
		Database database =new Database();
		database.openConnection();
		ResultSet rs = database.getKotaDari();
		while(rs.next()){
			String idkotadari = rs.getString(1);
			String kotadari = rs.getString(2);
			String[] row ={idkotadari,kotadari};
			model.addRow(row);
		}
		rs.close();
	}
}

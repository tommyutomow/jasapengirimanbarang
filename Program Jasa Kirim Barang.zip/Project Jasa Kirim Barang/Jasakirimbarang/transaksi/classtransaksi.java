package transaksi;

public class classtransaksi {
	private String idtransaksi;
	private String namapegawai;
	public String getNamapegawai() {
		return namapegawai;
	}
	public void setNamapegawai(String namapegawai) {
		this.namapegawai = namapegawai;
	}
	private String tgltransaksi;
	private String jamtransaksi;
	private String statusbarang;
	private String namapelangan;
	private String alamatrincian;
	private String namapenerima;
	private String telppenerima;
	private String namabarang;
	private String jenisbarang;
	private String beratbarang;
	private String paketoke;
	private String paketregular;
	private String paketyes;
	private String kotatujuan;
	private String kotadari;
	private int hargaperkg;
	private int totalharga;
	private int bayar;
	private int kembali;
	
	public String getIdtransaksi() {
		return idtransaksi;
	}
	public void setIdtransaksi(String idtransaksi) {
		this.idtransaksi = idtransaksi;
	}
	
	public String getTgltransaksi() {
		return tgltransaksi;
	}
	public void setTgltransaksi(String tgltransaksi) {
		this.tgltransaksi = tgltransaksi;
	}
	public String getJamtransaksi() {
		return jamtransaksi;
	}
	public void setJamtransaksi(String jamtransaksi) {
		this.jamtransaksi = jamtransaksi;
	}
	public String getStatusbarang() {
		return statusbarang;
	}
	public void setStatusbarang(String statusbarang) {
		this.statusbarang = statusbarang;
	}
	public String getNamapelangan() {
		return namapelangan;
	}
	public void setNamapelangan(String namapelangan) {
		this.namapelangan = namapelangan;
	}
	public String getAlamatrincian() {
		return alamatrincian;
	}
	public void setAlamatrincian(String alamatrincian) {
		this.alamatrincian = alamatrincian;
	}
	public String getNamapenerima() {
		return namapenerima;
	}
	public void setNamapenerima(String namapenerima) {
		this.namapenerima = namapenerima;
	}
	public String getTelppenerima() {
		return telppenerima;
	}
	public void setTelppenerima(String telppenerima) {
		this.telppenerima = telppenerima;
	}
	public String getNamabarang() {
		return namabarang;
	}
	public void setNamabarang(String namabarang) {
		this.namabarang = namabarang;
	}
	public String getJenisbarang() {
		return jenisbarang;
	}
	public void setJenisbarang(String jenisbarang) {
		this.jenisbarang = jenisbarang;
	}
	public String getBeratbarang() {
		return beratbarang;
	}
	public void setBeratbarang(String beratbarang) {
		this.beratbarang = beratbarang;
	}
	public String getPaketoke() {
		return paketoke;
	}
	public void setPaketoke(String paketoke) {
		this.paketoke = paketoke;
	}
	public String getPaketregular() {
		return paketregular;
	}
	public void setPaketregular(String paketregular) {
		this.paketregular = paketregular;
	}
	public String getPaketyes() {
		return paketyes;
	}
	public void setPaketyes(String paketyes) {
		this.paketyes = paketyes;
	}
	public String getKotatujuan() {
		return kotatujuan;
	}
	public void setKotatujuan(String kotatujuan) {
		this.kotatujuan = kotatujuan;
	}
	public String getKotadari() {
		return kotadari;
	}
	public void setKotadari(String kotadari) {
		this.kotadari = kotadari;
	}
	public int getHargaperkg() {
		return hargaperkg;
	}
	public void setHargaperkg(int hargaperkg) {
		this.hargaperkg = hargaperkg;
	}
	public int getTotalharga() {
		return totalharga;
	}
	public void setTotalharga(int totalharga) {
		this.totalharga = totalharga;
	}
	public int getBayar() {
		return bayar;
	}
	public void setBayar(int bayar) {
		this.bayar = bayar;
	}
	public int getKembali() {
		return kembali;
	}
	public void setKembali(int kembali) {
		this.kembali = kembali;
	}
	
	
}

package transaksi;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.text.DateFormatter;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.SwingConstants;
import java.awt.Color;
import javax.swing.JSeparator;
import javax.swing.JPopupMenu;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JDesktopPane;
import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JCheckBox;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.ActionEvent;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;

import java.awt.SystemColor;
import java.awt.Toolkit;

import javax.swing.UIManager;
import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class transaksi extends JFrame {
	public String paket ="";
	public int pil;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_3;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	private JTextField textField_10;
	private JTextField textField_11;
	private JTextField textField_12;
	private JTextField textField_13;
	private JTextField textField_14;

	/**
	 * Launch the application.
	 */
	private Connection conn = null;
	//private int a = 0;
	static final String driver = "com.mysql.jdbc.Driver";
	static final String db_url = "jdbc:mysql://localhost:3306/jasakirimbarang";
	static final String username = "root";
	static final String password= "";
	
	public void opendb() throws SQLException{
		conn = DriverManager.getConnection(db_url,username,password);
	}
	public void closedb() throws SQLException{
		if(conn!=null) conn.close();
	}
	
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					transaksi frame = new transaksi();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * @throws ClassNotFoundException 
	 * @throws SQLException 
	 */
	public transaksi() throws ClassNotFoundException, SQLException {
		super("Transaksi");
		
		databasetransaksi db =new databasetransaksi();
		//db.opendb();
		ArrayList<classtransaksi> arrkotatujuan = new ArrayList<classtransaksi>();
		arrkotatujuan = db.getkotatujuan();
		ArrayList<classtransaksi> arrkotadari = new ArrayList<classtransaksi>();
		arrkotadari = db.getkotadari();
		ArrayList<classtransaksi> arrcustomer = new ArrayList<classtransaksi>();
		arrcustomer  = db.getcustomer();
		ArrayList<classtransaksi> arrpegawai = new ArrayList<classtransaksi>();
		arrpegawai   = db.getpegawai();
		
		
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 1000, 650);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		Dimension frameSize = getSize();
		setLocation(
		(screenSize.width - frameSize.width) / 2,
		(screenSize.height - frameSize.height) / 2);
		
		JLabel lblFlash = new JLabel("Flash ");
		lblFlash.setForeground(new Color(255, 102, 0));
		lblFlash.setHorizontalAlignment(SwingConstants.RIGHT);
		lblFlash.setFont(new Font("Clarendon Blk BT", Font.BOLD | Font.ITALIC, 60));
		lblFlash.setBounds(0, -1, 493, 63);
		contentPane.add(lblFlash);
		
		JLabel lblExpress = new JLabel("Express");
		lblExpress.setHorizontalAlignment(SwingConstants.LEFT);
		lblExpress.setForeground(Color.BLUE);
		lblExpress.setFont(new Font("Clarendon Blk BT", Font.BOLD | Font.ITALIC, 30));
		lblExpress.setBounds(490, -1, 493, 63);
		contentPane.add(lblExpress);
		
		JLabel lblIdTransaksi = new JLabel("ID Transaksi");
		lblIdTransaksi.setFont(new Font("Arial Black", Font.PLAIN, 13));
		lblIdTransaksi.setBounds(92, 107, 149, 24);
		contentPane.add(lblIdTransaksi);
		
		JLabel lblIdPengawai = new JLabel("Nama Pengawai");
		lblIdPengawai.setFont(new Font("Arial Black", Font.PLAIN, 13));
		lblIdPengawai.setBounds(92, 142, 149, 24);
		contentPane.add(lblIdPengawai);
		
		JLabel lblTgltransaksi = new JLabel("Tgl Transaksi");
		lblTgltransaksi.setFont(new Font("Arial Black", Font.PLAIN, 13));
		lblTgltransaksi.setBounds(92, 177, 149, 24);
		contentPane.add(lblTgltransaksi);
		
		JLabel lblJam = new JLabel("Jam Transaksi");
		lblJam.setFont(new Font("Arial Black", Font.PLAIN, 13));
		lblJam.setBounds(92, 212, 149, 24);
		contentPane.add(lblJam);
		
		JLabel lblStatus = new JLabel("Status Barang");
		lblStatus.setFont(new Font("Arial Black", Font.PLAIN, 13));
		lblStatus.setBounds(92, 247, 149, 24);
		contentPane.add(lblStatus);
		
		JLabel lblAlamatRincian = new JLabel("Alamat Rincian");
		lblAlamatRincian.setFont(new Font("Arial Black", Font.PLAIN, 13));
		lblAlamatRincian.setBounds(92, 330, 149, 24);
		contentPane.add(lblAlamatRincian);
		
		JLabel lblNamaPelangan = new JLabel("Nama Customer");
		lblNamaPelangan.setFont(new Font("Arial Black", Font.PLAIN, 13));
		lblNamaPelangan.setBounds(92, 295, 149, 24);
		contentPane.add(lblNamaPelangan);
		
		JLabel lblNamaPenerima = new JLabel("Nama Penerima");
		lblNamaPenerima.setFont(new Font("Arial Black", Font.PLAIN, 13));
		lblNamaPenerima.setBounds(92, 424, 149, 24);
		contentPane.add(lblNamaPenerima);
		
		JLabel lblTelpPenerima = new JLabel("No Telp ");
		lblTelpPenerima.setFont(new Font("Arial Black", Font.PLAIN, 13));
		lblTelpPenerima.setBounds(92, 389, 149, 24);
		contentPane.add(lblTelpPenerima);
		
		JLabel label = new JLabel("Nama Barang");
		label.setFont(new Font("Arial Black", Font.PLAIN, 13));
		label.setBounds(92, 469, 149, 24);
		contentPane.add(label);
		
		JLabel lblJenisBarang = new JLabel("Jenis Barang");
		lblJenisBarang.setFont(new Font("Arial Black", Font.PLAIN, 13));
		lblJenisBarang.setBounds(92, 504, 149, 24);
		contentPane.add(lblJenisBarang);
		
		JLabel lblBeratBarang = new JLabel("Berat Barang");
		lblBeratBarang.setFont(new Font("Arial Black", Font.PLAIN, 13));
		lblBeratBarang.setBounds(92, 539, 149, 24);
		contentPane.add(lblBeratBarang);
		
		JLabel lblTotalHarga = new JLabel("Harga per kg");
		lblTotalHarga.setFont(new Font("Arial Black", Font.PLAIN, 13));
		lblTotalHarga.setBounds(586, 317, 149, 24);
		contentPane.add(lblTotalHarga);
		
		JLabel lblKotaDari = new JLabel("Kota Dari");
		lblKotaDari.setFont(new Font("Arial Black", Font.PLAIN, 13));
		lblKotaDari.setBounds(586, 247, 149, 24);
		contentPane.add(lblKotaDari);
		
		JLabel lblKotaTujuan = new JLabel("Kota Tujuan");
		lblKotaTujuan.setFont(new Font("Arial Black", Font.PLAIN, 13));
		lblKotaTujuan.setBounds(586, 282, 149, 24);
		contentPane.add(lblKotaTujuan);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(73, 282, 360, 16);
		contentPane.add(separator);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(73, 459, 360, 16);
		contentPane.add(separator_1);
		
		textField = new JTextField();
		textField.setBounds(251, 111, 135, 20);
		textField.setEditable(false);
		contentPane.add(textField);
		textField.setColumns(10);
		no_transaksi();
		
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(251, 216, 135, 20);
		contentPane.add(textField_3);
		
		textField_6 = new JTextField();
		textField_6.setColumns(10);
		textField_6.setBounds(251, 393, 135, 20);
		contentPane.add(textField_6);
		
		textField_7 = new JTextField();
		textField_7.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				e.setKeyChar(Character.toUpperCase(e.getKeyChar())); 
			}
		});
		textField_7.setColumns(10);
		textField_7.setBounds(251, 428, 135, 20);
		contentPane.add(textField_7);
		
		textField_8 = new JTextField();
		textField_8.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				e.setKeyChar(Character.toUpperCase(e.getKeyChar())); 
			}
		});
		textField_8.setColumns(10);
		textField_8.setBounds(251, 473, 135, 20);
		contentPane.add(textField_8);
		
		textField_10 = new JTextField();
		textField_10.setColumns(10);
		textField_10.setBounds(251, 543, 135, 20);
		contentPane.add(textField_10);
		
		textField_11 = new JTextField();
		textField_11.setColumns(10);
		textField_11.setEditable(false);
		textField_11.setBounds(731, 321, 135, 20);
		contentPane.add(textField_11);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Manifest", "On-Process", "On-Transit","Received On Destination","Delivered","Redelivery"}));
		comboBox.setBounds(251, 251, 135, 20);
		contentPane.add(comboBox);
		
		JComboBox comboBox_1 = new JComboBox();
		comboBox_1.setBounds(731, 251, 135, 20);
		for(int i=0;i<arrkotadari.size();i++){
			comboBox_1.addItem(arrkotadari.get(i).getKotadari());
		 }
		contentPane.add(comboBox_1);
		
		JComboBox comboBox_2 = new JComboBox();
		comboBox_2.setBounds(731, 286, 135, 20);
		contentPane.add(comboBox_2);
		for(int i=0;i<arrkotatujuan.size();i++){
			comboBox_2.addItem(arrkotatujuan.get(i).getKotatujuan());
		 }
		
		JLabel lblTotalHarga_1 = new JLabel("Total");
		lblTotalHarga_1.setFont(new Font("Arial Black", Font.PLAIN, 13));
		lblTotalHarga_1.setBounds(586, 389, 149, 24);
		contentPane.add(lblTotalHarga_1);
		
		textField_12 = new JTextField();
		textField_12.setColumns(10);
		textField_12.setEditable(false);
		textField_12.setBounds(731, 393, 135, 20);
		contentPane.add(textField_12);
		
		JLabel lblBayar = new JLabel("Bayar");
		lblBayar.setFont(new Font("Arial Black", Font.PLAIN, 13));
		lblBayar.setBounds(586, 424, 149, 24);
		contentPane.add(lblBayar);
		
		textField_13 = new JTextField();
		textField_13.setColumns(10);
		textField_13.setBounds(731, 428, 135, 20);
		contentPane.add(textField_13);
		
		JLabel lblKembali = new JLabel("Kembali");
		lblKembali.setFont(new Font("Arial Black", Font.PLAIN, 13));
		lblKembali.setBounds(586, 459, 149, 24);
		contentPane.add(lblKembali);
		
		textField_14 = new JTextField();
		textField_14.setColumns(10);
		textField_14.setEditable(false);
		textField_14.setBounds(731, 463, 135, 20);
		contentPane.add(textField_14);
		
		JComboBox comboBox_3 = new JComboBox();
		comboBox_3.setModel(new DefaultComboBoxModel(new String[] {"Elektronik", "Pakaian", "Aksesoris","Dokumen","Makanan","Pecah Belah","Dan Lain Lain"}));
		comboBox_3.setBounds(251, 508, 135, 20);
		contentPane.add(comboBox_3);
		
		JRadioButton rdbtnPaketoke = new JRadioButton("Paket Oke");
		rdbtnPaketoke.setBackground(SystemColor.activeCaption);
		rdbtnPaketoke.setBounds(654, 129, 109, 23);
		contentPane.add(rdbtnPaketoke);
		
		JRadioButton rdbtnPaketRegular = new JRadioButton("Paket Regular");
		rdbtnPaketRegular.setBackground(SystemColor.activeCaption);
		rdbtnPaketRegular.setBounds(654, 165, 109, 23);
		contentPane.add(rdbtnPaketRegular);
		
		JRadioButton rdbtnPaketYes = new JRadioButton("Paket YES");
		rdbtnPaketYes.setBackground(SystemColor.activeCaption);
		rdbtnPaketYes.setBounds(654, 202, 109, 23);
		contentPane.add(rdbtnPaketYes);
		
		JTabbedPane tabbedPane_1 = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane_1.setBounds(615, 94, 199, 142);
		contentPane.add(tabbedPane_1);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane_1.addTab("Paket", null, tabbedPane, null);
		
		JTextArea textArea = new JTextArea();
		textArea.setBounds(251, 332, 199, 50);
		contentPane.add(textArea);
		
		ButtonGroup group = new ButtonGroup();
		group.add(rdbtnPaketoke);
		group.add(rdbtnPaketRegular);
		group.add(rdbtnPaketYes);
		
		JButton btnHitung = new JButton("<<");
		btnHitung.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(rdbtnPaketoke.isSelected()){
					//System.out.println("Paket Oke");
					String kotadari  = comboBox_1.getSelectedItem().toString();
					String kotatujuan  = comboBox_2.getSelectedItem().toString();
					//System.out.println(kotadari);
					//System.out.println(kotatujuan);
					try {
						opendb();
						Statement stmt = conn.createStatement();
						ResultSet rs = stmt.executeQuery("SELECT * FROM paketoke where Kota_Dari='"+kotadari+"' and Kota_Tujuan='"+kotatujuan+"'");
						
						while(rs.next()){
							classtransaksi customer = new classtransaksi();
							 int a = rs.getInt("Hargakg");
							 String hasilkestring = Integer.toString(a);
							 textField_11.setText(hasilkestring);
						 }
						int berat = (int) Double.parseDouble(textField_10.getText());
						int hargakg = (int) Double.parseDouble(textField_11.getText());

						int total = berat * hargakg;
						String totalkestring = Integer.toString(total);
						textField_12.setText(totalkestring);
						rs.close();
						closedb();
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
	
				}else if(rdbtnPaketRegular.isSelected()){
					//System.out.println("Paket Oke");
					String kotadari  = comboBox_1.getSelectedItem().toString();
					String kotatujuan  = comboBox_2.getSelectedItem().toString();
					//System.out.println(kotadari);
					//System.out.println(kotatujuan);
					try {
						opendb();
						Statement stmt = conn.createStatement();
						ResultSet rs = stmt.executeQuery("SELECT * FROM paketreguler where Kota_Dari='"+kotadari+"' and Kota_Tujuan='"+kotatujuan+"'");
						
						while(rs.next()){
							classtransaksi customer = new classtransaksi();
							 int a = rs.getInt("Hargakg");
							 String hasilkestring = Integer.toString(a);
							 textField_11.setText(hasilkestring);
						 }
						int berat = (int) Double.parseDouble(textField_10.getText());
						int hargakg = (int) Double.parseDouble(textField_11.getText());

						int total = berat * hargakg;
						String totalkestring = Integer.toString(total);
						textField_12.setText(totalkestring);
						rs.close();
						closedb();
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}else if(rdbtnPaketYes.isSelected()){
					String kotadari  = comboBox_1.getSelectedItem().toString();
					String kotatujuan  = comboBox_2.getSelectedItem().toString();
					try {
						opendb();
						Statement stmt = conn.createStatement();
						ResultSet rs = stmt.executeQuery("SELECT * FROM paketyes where Kota_Dari='"+kotadari+"' and Kota_Tujuan='"+kotatujuan+"'");
						
						while(rs.next()){
							classtransaksi customer = new classtransaksi();
							 int a = rs.getInt("Hargakg");
							 String hasilkestring = Integer.toString(a);
							 textField_11.setText(hasilkestring);
						 }
						int berat = (int) Double.parseDouble(textField_10.getText());
						int hargakg = (int) Double.parseDouble(textField_11.getText());

						int total = berat * hargakg;
						String totalkestring = Integer.toString(total);
						textField_12.setText(totalkestring);
						rs.close();
						closedb();
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					//System.out.println("Paket YES");
					
				}
			}
		});
		btnHitung.setBounds(875, 320, 53, 23);
		contentPane.add(btnHitung);
		
		JComboBox comboBox_4 = new JComboBox();
		comboBox_4.setEditable(true);
		comboBox_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String nama = comboBox_4.getSelectedItem().toString();
				try {
					opendb();
					Statement stmt;
					stmt = conn.createStatement();
					ResultSet rs = stmt.executeQuery("SELECT alamat,telepon FROM customer where nama='"+nama+"'");
					while(rs.next()){
						Object[] ob = new Object[2];
						ob[0]= rs.getString(1); 
						ob[1]= rs.getString(2); 
						
						textArea.setText((String) ob[0]);
						textField_6.setText((String) ob[1]);
					}
					rs.close();
					closedb();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				
			}
		});
		comboBox_4.setBounds(251, 299, 176, 20);
		contentPane.add(comboBox_4);
		for(int i=0;i<arrcustomer.size();i++){
			comboBox_4.addItem(arrcustomer.get(i).getNamapelangan());
		 }
		
		JComboBox comboBox_5 = new JComboBox();
		comboBox_5.setBounds(251, 146, 135, 20);
		contentPane.add(comboBox_5);
		for(int i=0;i<arrpegawai.size();i++){
			comboBox_5.addItem(arrpegawai.get(i).getNamapegawai());
		 }
		
		
		DateFormat tglformat = new SimpleDateFormat("dd-MMMM-yyyy");
		DateFormatter df  = new DateFormatter(tglformat);
		
		JFormattedTextField formattglahir= new JFormattedTextField(df);
		formattglahir.setValue(new Date());
		formattglahir.setEditable(false);
		formattglahir.setBounds(251, 181, 135, 20);
		contentPane.add(formattglahir);
		
		java.util.Date dateTime = new java.util.Date();
		String nol_jam = "", nol_menit = "",nol_detik = "";
		int nilai_jam = dateTime.getHours();
		int nilai_menit = dateTime.getMinutes();
		int nilai_detik = dateTime.getSeconds();

		if(nilai_jam <= 9)  nol_jam= "0";
		if(nilai_menit <= 9) nol_menit= "0";
		if(nilai_detik <= 9) nol_detik= "0";
		
		String jam = nol_jam + Integer.toString(nilai_jam);
		String menit = nol_menit + Integer.toString(nilai_menit);
		String detik = nol_detik + Integer.toString(nilai_detik);
		
		textField_3.setText(jam+":"+menit+":"+detik+"");
		textField_3.setEditable(false);
		
		
		JButton btnHitung_1 = new JButton("Submit");
		btnHitung_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String notransaksi = textField.getText();
				int total = (int) Double.parseDouble(textField_12.getText());
				int bayar = (int) Double.parseDouble(textField_13.getText());
				int kembali = bayar -total;
				String kembalikestring = Integer.toString(kembali);
				textField_14.setText(kembalikestring);
			
				String id = textField.getText();
				String nama = comboBox_5.getSelectedItem().toString();
				String tgl  = formattglahir.getText();
				String jam = textField_3.getText();
				String status = comboBox.getSelectedItem().toString();
				String namacus = comboBox_4.getSelectedItem().toString();
				String alamatcus = textArea.getText();
				String notelp = textField_6.getText();
				String namapenerima = textField_7.getText();
				String namabarang=textField_8.getText();
				String jenisbarang = comboBox_3.getSelectedItem().toString();
				int berat = (int) Double.parseDouble(textField_10.getText());
				
				String paket="";
				if (rdbtnPaketoke.isSelected()){
					paket = rdbtnPaketoke.getText();
				}else if (rdbtnPaketRegular.isSelected()){
					paket = rdbtnPaketRegular.getText();
				}else if (rdbtnPaketYes.isSelected()){
					paket = rdbtnPaketYes.getText();
				}
				
				String kotadari = comboBox_1.getSelectedItem().toString();
				String kotatujuan = comboBox_2.getSelectedItem().toString();
				int hargakg = (int) Double.parseDouble(textField_11.getText());
				int kembalian = (int) Double.parseDouble(textField_14.getText());
				
				try {
					db.opendb();
					db.addtransaksi(id,nama,tgl,jam,status,namacus,alamatcus,notelp,namapenerima,namabarang,jenisbarang,berat,paket,kotadari,kotatujuan,hargakg,total,bayar,kembalian);
				    db.closedb();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				final JTextArea txtrFlashExpress = new JTextArea();
			  	txtrFlashExpress.setTabSize(4);
			  	txtrFlashExpress.setWrapStyleWord(true);
			  	txtrFlashExpress.setFont(new Font("Arial", Font.PLAIN, 11));
			  	txtrFlashExpress.setLineWrap(true);
			    txtrFlashExpress.setText("\t\t\t\t\tFLASH Express\r\n"
			    		+ "\t\tJl. Scientia Boulevard, Gading Serpong, Kec. Tangerang, Banten\r\n\r\n"
			    		+"----------------------------------------------------------------------------------------------------------------\r\n"
			    		+ "No Transaksi : "+notransaksi+"\r\n"
			    		+ "----------------------------------------------------------------------------------------------------------------\r\n"
			    		+ "Kota Asal  : "+kotadari+"                                                             	 Kota Tujuan: "+kotatujuan+"\r\n"
			    		+ "Pengirim   : "+namacus+"\r\n"
			    		+ "No Telp    : "+notelp+"\r\n"
			    		+ "\r\nPenerima : "+namapenerima+"\r\n----------------------------------------------------------------------------------------------------------------\r\n"
			    		+ "Layanan   : "+paket+"\r\n"
			    		+ "Jenis Kiriman : "+jenisbarang+"\r\n"
			    		+ "\r\n----------------------------------------------------------------------------------------------------------------\r\n"
			    		+ "Nama Barang \t\t\t\t\t\t"
			    		+ "Berat\t\r\n\r\n"
			    		+  namabarang+" \t\t\t\t\t"
			    		+  berat+" \t\r\n\r\n"
			    		+ "----------------------------------------------------------------------------------------------------------------\r\n"
			    		+ "\r\nBerat \t       	: \t\t\t\t\t\t\t\t"
			    		+ berat+" KG\r\n"
			    		+ "Harga            : IDR\t\t\t\t\t\t\t\t"
			    		+ hargakg+"\r\n"
			    		+ "Total            : IDR\t\t\t\t\t\t\t\t"
			    		+ total+"\t\t\t\t\t\t\t\t\t\t\r\n"
			    		+ "\r\n\r\n         PETUGAS\t\t\t\t\t\t\tPENGIRIM\r\n\r\n"
			    		+ "\r\n\r\n           ("+nama+")\t\t\t\t\t\t("+namacus+")");
			    JScrollPane jScrollPane = new JScrollPane(txtrFlashExpress);
			    final MessageFormat header = new MessageFormat("FLASH EXPRESS");
			    final MessageFormat footer = new MessageFormat("My Footer");

			    JPanel contentPane = new JPanel();
			    contentPane.setLayout(new BorderLayout());
			    contentPane.add(jScrollPane, BorderLayout.CENTER);

			    JFrame frame = new JFrame();
			    frame.setTitle("Print");
			    frame.setSize(500, 510);
			    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

			    frame.setContentPane(contentPane);
			    frame.setVisible(false);
			    try {
					txtrFlashExpress.print(header, footer, true, null, null, true);
					System.exit(0);
				} catch (PrinterException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		btnHitung_1.setFont(new Font("Arial Black", Font.BOLD, 14));
		btnHitung_1.setBounds(731, 521, 123, 34);
		contentPane.add(btnHitung_1);
		
		JSeparator separator_2 = new JSeparator();
		separator_2.setBounds(569, 362, 360, 16);
		contentPane.add(separator_2);
		
		
		
	}
	
	public void no_transaksi() throws SQLException{
		opendb();
		Statement stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery("SELECT ID_Transaksi FROM transaksi ORDER by ID_Transaksi desc");
	
		if (rs.next()){
			int auto_no = Integer.parseInt(rs.getString("ID_Transaksi"))+1;
			textField.setText(Integer.toString(auto_no));
		}else{
			int auto_no =1;
			textField.setText(Integer.toString(auto_no));
		}
		rs.close();
		closedb();
	}
}

package transaksi;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.swing.JOptionPane;

import paketoke.classpaketOke;

public class databasetransaksi {
	private Connection conn = null;
	private int a = 0;
	static final String driver = "com.mysql.jdbc.Driver";
	static final String db_url = "jdbc:mysql://localhost:3306/jasakirimbarang";
	static final String username = "root";
	static final String password= "";
	
	
	public databasetransaksi() throws ClassNotFoundException{
		Class.forName(driver);
	}
	
	public void opendb() throws SQLException{
		conn = DriverManager.getConnection(db_url,username,password);
	}
	
	public void closedb() throws SQLException{
		if(conn!=null) conn.close();
	}
	
	
	public ArrayList<classtransaksi> getkotatujuan() throws SQLException{
		opendb();
		Statement stmt = conn.createStatement();
		ResultSet rs  = stmt.executeQuery("SELECT * FROM kotatujuan ORDER BY Nama_KotaTujuan ASC");
		
		ArrayList<classtransaksi> arr = new ArrayList<classtransaksi>();
		while (rs.next()){
			classtransaksi kotatujuan = new classtransaksi();
			kotatujuan.setKotatujuan(rs.getString(2));
			arr.add(kotatujuan);
		}
		closedb();
		return arr;
	}
	
	public ArrayList<classtransaksi> getkotadari() throws SQLException{
		opendb();
		Statement stmt = conn.createStatement();
		ResultSet rs  = stmt.executeQuery("SELECT * FROM kotadari ORDER BY Nama_KotaDari ASC");
		
		ArrayList<classtransaksi> arr = new ArrayList<classtransaksi>();
		while (rs.next()){
			classtransaksi kotadari = new classtransaksi();
			kotadari.setKotadari(rs.getString(2));
			arr.add(kotadari);
		}
		closedb();
		return arr;
	}
	
	public ArrayList<classtransaksi> getcustomer() throws SQLException{
		opendb();
		Statement stmt = conn.createStatement();
		ResultSet rs  = stmt.executeQuery("SELECT * FROM customer");
		
		ArrayList<classtransaksi> arr = new ArrayList<classtransaksi>();
		while (rs.next()){
			classtransaksi customer = new classtransaksi();
			customer.setNamapelangan(rs.getString(2));
			arr.add(customer);
		}
		closedb();
		return arr;
	}
	
	public ArrayList<classtransaksi> getpegawai() throws SQLException{
		opendb();
		Statement stmt = conn.createStatement();
		ResultSet rs  = stmt.executeQuery("SELECT * FROM pegawai where Hak_User = 'Pegawai'");
		
		ArrayList<classtransaksi> arr = new ArrayList<classtransaksi>();
		while (rs.next()){
			classtransaksi pegawai = new classtransaksi();
			pegawai.setNamapegawai(rs.getString(2));
			arr.add(pegawai);
		}
		closedb();
		return arr;
	}
	
	public void addtransaksi(String ID_Transaksi, String Nama_Pengawai, String Tgl_Transaksi,String Jam_Transaksi, String Status_Barang, String Nama_Customer,String Alamat_Rincian,String No_Telp, String Nama_Penerima,String Nama_Barang,String Jenis_Barang, int Berat_Barang, String Paket, String Kota_Dari, String Kota_Tujuan, int Hargaperkg, int Total_Harga, int Bayar,int Kembali) throws SQLException{
		opendb();
		String query = "INSERT INTO transaksi(ID_Transaksi, Nama_Pengawai, Tgl_Transaksi, Jam_Transaksi, Status_Barang, Nama_Customer, Alamat_Rincian, No_Telp, Nama_Penerima, Nama_Barang, Jenis_Barang, Berat_Barang, Paket, Kota_Dari, Kota_Tujuan, Hargaperkg, Total_Harga, Bayar, Kembali) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		PreparedStatement ps = conn.prepareStatement(query);
		
		// Index dimulai dari 1 bukan 0. Index merepresentasikan urutan ?
		ps.setString(1, ID_Transaksi);
		ps.setString(2, Nama_Pengawai);
		ps.setString(3, Tgl_Transaksi);
		ps.setString(4, Jam_Transaksi);
		ps.setString(5, Status_Barang);
		ps.setString(6, Nama_Customer);
		ps.setString(7, Alamat_Rincian);
		ps.setString(8, No_Telp);
		ps.setString(9, Nama_Penerima);
		ps.setString(10, Nama_Barang);
		ps.setString(11, Jenis_Barang);
		ps.setInt(12, Berat_Barang);
		ps.setString(13, Paket);
		ps.setString(14, Kota_Dari);
		ps.setString(15, Kota_Tujuan);
		ps.setInt(16, Hargaperkg);
		ps.setInt(17, Total_Harga);
		ps.setInt(18, Bayar);
		ps.setInt(19, Kembali);
		
		conn.setAutoCommit(false);
		int result = ps.executeUpdate();
		if(result == 1){
			JOptionPane.showMessageDialog(null,"Data berhasil di simpan");
			conn.commit();
		}else{
			JOptionPane.showMessageDialog(null,"Data gagal di simpan");
		}
		closedb();
	}
	
}

package Login;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JOptionPane;

import KotaDari.KotaDari;
import menuadmin.menuadmin;
import menupegawai.menupegawai;

public class databaseLogin {
	private Connection conn = null;
	static final String driver = "com.mysql.jdbc.Driver";
	static final String db_url = "jdbc:mysql://localhost:3306/jasakirimbarang";
	static final String username = "root";
	static final String password= "";
	
	public databaseLogin() throws ClassNotFoundException{
		Class.forName(driver);
	}
	
	public void opendb() throws SQLException{
		conn = DriverManager.getConnection(db_url,username,password);
	}
	
	public void closedb() throws SQLException{
		if(conn!=null) conn.close();
	}
	
	public void login(String username, String password) throws SQLException, ClassNotFoundException{
		opendb();
		Statement stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery("SELECT * FROM pegawai where Username='"+username+"' and Password='"+password+"'");
		String HakUser = "Admin";
		String HakUser1 = "Pegawai";
		if(rs.next()){
			if(HakUser.equals(rs.getString("Hak_User"))){
				JOptionPane.showMessageDialog(null, "Login Admin Berhasil!");	
				new menuadmin().setVisible(true);
				
			}else if(HakUser1.equals(rs.getString("Hak_User"))){
					JOptionPane.showMessageDialog(null, "Login Pengawai Berhasil!");
					new menupegawai().setVisible(true);
			}
		}else{
			JOptionPane.showMessageDialog(null, "Username dan Password Anda Salah, Silakan Ulang!");
		}
		closedb();
	}
	
	
}

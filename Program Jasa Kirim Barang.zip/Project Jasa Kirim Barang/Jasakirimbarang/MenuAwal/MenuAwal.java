package MenuAwal;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Customer.customerFrame;
import Login.login;
import menucustomer.menucustomer;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JSeparator;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class MenuAwal extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MenuAwal frame = new MenuAwal();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MenuAwal() {
		super("Flash Express");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 344);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		Dimension frameSize = getSize();
		setLocation(
		(screenSize.width - frameSize.width) / 2,
		(screenSize.height - frameSize.height) / 2);
		
		
		
		JLabel lblNewLabel = new JLabel("Pegawai");
		lblNewLabel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					new login().setVisible(true);
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		lblNewLabel.setForeground(new Color(102, 204, 0));
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 30));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(33, 98, 358, 75);
		contentPane.add(lblNewLabel);
		
		JLabel lblCustomer = new JLabel("Customer");
		lblCustomer.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				new menucustomer().setVisible(true);
			}
		});
		lblCustomer.setForeground(new Color(102, 153, 255));
		lblCustomer.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 30));
		lblCustomer.setHorizontalAlignment(SwingConstants.CENTER);
		lblCustomer.setBounds(33, 198, 358, 75);
		contentPane.add(lblCustomer);
		
		JLabel label = new JLabel("Flash ");
		label.setHorizontalAlignment(SwingConstants.RIGHT);
		label.setForeground(new Color(255, 102, 0));
		label.setFont(new Font("Clarendon Blk BT", Font.BOLD | Font.ITALIC, 50));
		label.setBounds(0, 0, 235, 73);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("Express");
		label_1.setForeground(Color.BLUE);
		label_1.setFont(new Font("Clarendon Blk BT", Font.BOLD, 30));
		label_1.setBounds(230, 0, 204, 71);
		contentPane.add(label_1);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(31, 71, 360, 16);
		contentPane.add(separator);
	}
}
